#!bin/usr/python
print ("Hola Mundo")
raw_input()
variable = "esta es la variable 1"

print (variable)

mi_cadena_multilinea = """
Esta es una cadena
de varias lineas
"""

print (mi_cadena_multilinea)
