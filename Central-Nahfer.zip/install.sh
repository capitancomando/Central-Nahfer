#!/bin/bash

# creado por nahfer sociedad hacking
setterm -foreground green
clear

echo "
     
            ██████▓█████▓▓╬╬╬╬╬╬╬╬▓███▓╬╬╬╬╬╬╬▓╬╬▓█
            ████▓▓▓▓╬╬▓█████╬╬╬╬╬╬███▓╬╬╬╬╬╬╬╬╬╬╬╬╬█
            ███▓▓▓▓╬╬╬╬╬╬▓██╬╬╬╬╬╬▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█
            ████▓▓▓╬╬╬╬╬╬╬▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█
            ███▓█▓███████▓▓███▓╬╬╬╬╬╬▓███████▓╬╬╬╬▓█
            ████████████████▓█▓╬╬╬╬╬▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬█
            ███▓▓▓▓▓▓▓▓▓▓▓▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█
            ████▓▓▓▓▓▓▓▓▓▓▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█
            ███▓█▓▓▓▓▓▓▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█
            █████▓▓▓▓▓▓▓▓█▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█
            █████▓▓▓▓▓▓▓██▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬██
            █████▓▓▓▓▓████▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬██
            ████▓█▓▓▓▓██▓▓▓▓██╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬██
            ████▓▓███▓▓▓▓▓▓▓██▓╬╬╬╬╬╬╬╬╬╬╬╬█▓╬▓╬╬▓██
            █████▓███▓▓▓▓▓▓▓▓████▓▓╬╬╬╬╬╬╬█▓╬╬╬╬╬▓██
            █████▓▓█▓███▓▓▓████╬▓█▓▓╬╬╬▓▓█▓╬╬╬╬╬╬███
            ██████▓██▓███████▓╬╬╬▓▓╬▓▓██▓╬╬╬╬╬╬╬▓███
            ███████▓██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬████
            ███████▓▓██▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓████
            ████████▓▓▓█████▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓█████
            █████████▓▓▓█▓▓▓▓▓███▓╬╬╬╬╬╬╬╬╬╬╬▓██████
            ██████████▓▓▓█▓▓▓▓▓██╬╬╬╬╬╬╬╬╬╬╬▓███████
            ███████████▓▓█▓▓▓▓███▓╬╬╬╬╬╬╬╬╬▓████████
            ██████████████▓▓▓███▓▓╬╬╬╬╬╬╬╬██████████
            ███████████████▓▓▓██▓▓╬╬╬╬╬╬▓███████████

"

sleep 2
clear
setterm -foreground green
echo "
     ╔════════════════════════════════════════════════════╗
     ╠═══> Creador: Capitán Comandó and comander-747.     ║
     ╠═══> Version de la herramienta: V6.1 Remasterizado. ║
     ╠═══> Comunity hacking programations.                ║   
     ╠═══> Nahfer-Hacking                                 ║
     ║                                                    ║
     ╠═════════════════════[MENU]═════════════════════════╝
     ║~~>[MENU]
     ║
     ╠═[1]═> Instalacion Termux.
     ╠═[2]═> Instalacion en Userland,debian
     ╠═[3]═> Instalacion de modulos python
     ╠═[4]═> Salir
     ║"
 read -p $'     ╚══════════════════════>$"' option

if [[ $option == 1 ]]; then

     cd $HOME/Central-Nahfer/.config/datos/textos-temporales
cp nahfer //usr/local/bin/
chmod 777 nahfer
cd $HOME/Central-Nahfer
pkg install figlet
pkg install python -y
pkg install python2 -y
pkg install python3 -y
pkg install dialog -y
pkg install play-audio -y
pkg install php -y
pkg install neofetch -y
pkg install w3m -y
apt install tsu  -y
apt install zip -y
pkg install nmap -y
pkg install python python2 figlet toilet ruby nodejs -y
pkg install tor -y
pkg install curl -y
pkg install wget -y
pkg install sshpass netcat
apt install -y sshpass netcat
pkg install ssh
            
elif [[ $option == 2 ]]; then

cd $HOME/Central-Nahfer/.config/datos/textos-temporales
sudo cp nahfer //usr/local/bin/
sudo chmod 777 nahfer
cd $HOME/Central-Nahfer
sudo apt-get install figlet
sudo apt-get install dialog -y
sudo apt-get install tor -y
sudo apt install curl -y
sudo apt install wget -y
sudo apt install nmap -y
sudo apt-get install zip -y
sudo apt install python2 -y
sudo apt install python -y
sudo apt install python3 -y
sudo apt install php -y
sudo apt install neofetch -y
sudo apt install w3m -y
apt-get install -y sshpass netcat
apt-get install ssh 

elif [[ $option == 3 ]]; then
clear
figlet "instalando" 
figlet "modulos" 
figlet "python" 
pip install scapy
pip install shodan
pip3 install mechanize
pip3 install proxylist
pip3 install argparse
pip install socks
pip3 install mechanicalsoup
pip2 install requests
pip2 install fake-useragent
pip2 install bs4
pip2 install html5lib
pip2 install phonenumbers
pip2 install argparse
pip2 install urllib3
pip2 install colorama
pip3 install proxylist
pip3 install pysocks
pip install lolcat
pip2 install lolcat
pip3 install lolcat
pip2 install pytube
pip2 install gtts
pip2 install bs4
pip2 install time
pip2 install json
pip2 install urllib
pip2 install urllib2
pip2 install socket
pip2 installhttplib
pip2 install hashlib
pip2 install datetime
pip2 install termcolor
pip2 install requests
pop2 install mechanize
pip2 install subprocess
pip2 install HTMLParser
pip2 install BeautifulSoup
pip2 install --upgrade html5lib
pip2 install --upgrade beautifulsoup4
npm install -g bash-obfuscate
gem install lolcat -y
pip install requests
pip2 install requests

else
printf "\e[1;93m [!] Invalid option!\e[0m\n"
menu
fi
