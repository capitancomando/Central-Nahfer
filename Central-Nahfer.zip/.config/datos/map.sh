#!/bin/bash

#Banner
R='\033[1;31m'
G='\033[1;32m'
Y='\033[1;33m'
blue='\033[1;32m'
magenta='\033[1;31m'
cyan='\033[1;36m'
W='\033[1;37m'
Green='\033[32m'
Gren='\033[32m'
Gris='\033[90m'
magentas='\033[0;31m'
echo $(clear)
echo -e "$magentas###########################################################"
echo -e "$blue
           . .IIIII             .II
  IIIIIII. I  II  .    II..IIIIIIIIIIIIIIIIIIII
 .  .IIIIII  II          III$cyan      $blue IIIIIIIIII.
    .IIIII.III I      IIIIIIIII$cyan    $blue IIIIIIIII  I
   .IIIIII$cyan Comander$blue II  .IIII$cyan  Anonymous$blue III. III
    IIIIIII$cyan  -747$blue   ' IIIII I IIIIIIIIIIII III I
    .II$cyan     Nahfer$blue   IIIIIIIIIIII  IIIIIIIIII
       I.           .IIIIIIIIIIII   I   II  I
         .IIII        IIIIIIIIIIII     .       I
          IIIII.          IIIIII           . I.
         IIIIIIIII         IIIII             ..I  II .
          IIIIIII          IIII..             IIQII
            IIII           III. I            IIIEIII
            III             I                I  IPI
             II     $cyan  [-]$magenta Nahfer$cyan [-]$blue         D   .
             I          $magenta Hacking$reset 
	     \n"
echo -e "$magentas###########################################################"
