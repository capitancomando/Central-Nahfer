# code create by comander 747
clear
echo "
el creador de este script es comander-747 
forever is Nahfer
somos hackers somos nahfer
Nahfer hacking programations
saludos a todos aquellos nahferianos 
de parte de comando" | lolcat -a