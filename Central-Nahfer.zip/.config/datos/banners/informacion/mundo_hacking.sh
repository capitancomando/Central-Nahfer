clear
echo "EXPLICACION DEL APARTADO.
------------------------------------------------------
Termux: en esta opcion hay herramientas para este emulador.
exactamente esta opcion es para aquellos hackers que utilizan
herramientas emuladas en esta aplicacion.
------------------------------------------------------"| lolcat -a
echo "KALI LINUX: en este apartado hay herramientas para kali linux.
------------------------------------------------------
DEBIAN,UBUNTU,y BASADOS: en este apartado hay herramientas 
medias universales que tambien corren en varias distribuciones,
Por ejemplo herramientas para kali linux." | lolcat -a
echo "------------------------------------------------------
ARCH LINUX Y ALPHINE: ESTA OPCION AUN NO ESTA DISPONIBLE.
------------------------------------------------------"| lolcat -a
echo "SI UTILIZAS TERMUX Y NO TIENES PC Y QUIERES UTILIZAR TODAS LAS HERRAMIENTAS
DEL MENU: TE RECOMIENDO
LA APLICACION PARA ANDROID LLAMADA:(USERLAND)
LA PUEDES DESCARGAR DESDE LA PLAY STORES
CON ESA APLICACION PODRAS UTILIZAR ESTAS HERRAMIENTAS AL 99%
PUEDES EMULAR DEBIAN,UBUNTU,KALI,ARCH,ALPHINE.
---------------------------------------------------- "| lolcat
echo
echo "click enter para salir" | lolcat -a
read
