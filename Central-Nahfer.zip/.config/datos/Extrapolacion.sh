#!bin/bash
clear

amarillo="\033[1;33m"
blanco="\033[1;37m"
rojo="\033[1;31m"

R='\033[1;31m'
G='\033[1;32m'
Y='\033[1;33m'
B='\033[1;34m'
M='\033[1;35m'
C='\033[1;36m'
W='\033[1;37m'
Green='\033[32m'
Gren='\033[32m'
Gris='\033[90m'

clear
echo
echo -e $Y"            @@@@@@@@@@@@@@@@@@"
echo -e $Y"         @@@@@@@@@@@@@@@@@@@@@@@"
echo -e $Y"       @@@@@@@@@@@@@@@@@@@@@@@@@@@     $Green<-- Creador Osiris --> "
echo -e $Y"      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
echo -e $Y"     @@@@@@@@@@@@@@@/      \@@@/   @"
echo -e $Y"     @@@@@@@@@@@@@@@@\      @@  @___@"
echo -e $Y"    @@@@@@@@@@@@@ @@@@@@@@@@  | \@@@@@     $Green<-- Forever is hacking! --> "
echo -e $Y"    @@@@@@@@@@@@@ @@@@@@@@@\__@_/@@@@@ "
echo -e $Y"     @@@@@@@@@@@@@@@/,/,/./'/_|.\'\,\ "
echo -e $Y"       @@@@@@@@@@@@@|  | | | | | | | |"
echo -e $Y"                     \_|_|_|_|_|_|_|_| "
echo

echo " "
echo -e $rojo" "
read -p "----> Escribe la CC a extrapolar : " Extrapolacion
echo -e $blanco" "
echo -e "$rojo--> $blanco${Extrapolacion:0:12}xxxx "
echo -e "$rojo--> $blanco${Extrapolacion:0:11}xxxxx "
echo -e "$rojo--> $blanco${Extrapolacion:0:8}xxxx${Extrapolacion:12:1}x${Extrapolacion:14:16} "
echo -e "$rojo--> $blanco${Extrapolacion:0:10}xxxxxx "
echo -e "$rojo--> $blanco${Extrapolacion:0:6}x${Extrapolacion:7:1}x${Extrapolacion:9:1}x${Extrapolacion:11:1}x${Extrapolacion:13:1}x${Extrapolacion:15:1} "

echo -e $G " "
read -p "()> Quieres volver al menu? Escribe Si/No: " MenuVolver



if [ $MenuVolver = Si ]; then
cd .. && bash Osiris-bgo.sh
fi

if [ $MenuVolver = si ]; then
cd .. && bash Osiris-bgo.sh
fi

if [ $MenuVolver = no ]; then
exit
fi

if [ $MenuVolver = No ]; then
exit
fi

