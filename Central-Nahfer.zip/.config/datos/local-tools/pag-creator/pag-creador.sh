
function inicio(){ 
clear
setterm -foreground green
while true; do
    read -p "
     ╔════════════════════════════════════════════════════╗
     ╠═══> Creador: Capitán Comandó and comander-747.     ║
     ╠═══> Version de la herramienta: V1.0 Remasterizado. ║
     ╠═══> Comunity hacking programations.                ║   
     ╠═══> Nahfer-Hacking                                 ║
     ║                                                    ║
     ╠═════════════════════[MENU]═════════════════════════╝
     ║~~>[MENU] Los trabajos se guardaran en descargas.
     ║
     ╠═[1]═> Apoyame.
     ╠═[2]═> Crear blog en html.
     ╠═[3]═> Crear pagina en html y css
     ╠═[4]═> Informacion.
     ╠═[5]═> Salir
     ║
     ╚══════════════════════>$" op
            case $op in
            [1]* ) carpeta_de_trabajo ; break;;
            [2]* ) carpeta_de_trabajo ; break;;
            [3]* ) carpeta_de_trabajo ; break;;
            [4]* ) carpeta_de_trabajo ; break;;
            [5]* ) carpeta_de_trabajo ; break;;

* ) echo "opcion incorrecta.";;
    esac
    sleep 0.1
    clear
done
}
function como_quieres_la_imagen(){
while true; do
    read -p "
     ╔════════════════════════════════════════════════════╗
     ╠═══> Creador: Capitán Comandó and comander-747.     ║
     ╠═══> Version de la herramienta: V1.0 Remasterizado. ║
     ╠═══> Comunity hacking programations.                ║   
     ╠═══> Nahfer-Hacking                                 ║
     ║                                                    ║
     ╠═════════════════════[MENU]═════════════════════════╝
     ║~~>[MENU]
     ║
     ╠═[1]═> Agregar imagen automatica.
     ╠═[2]═> Agregar imagen manual.
     ╚══════════════════════>$" op
            case $op in
            [1]* ) automatica ; break;;
            [2]* ) imagenes ; break;;
            
            
            
* ) echo "opcion incorrecta.";;
    esac
    sleep 0.1
    clear
done
}

function automatica(){
cp .no_eliminar.jpg images
cd images
echo -e "\e[1;32mcomo llamaras ala imagen?\e[0m"
read -p "-->" name_images
mv .no_eliminar.jpg $name_images.jpg
cd ..
echo -e "\e[1;32melige un lugar para la imagen (recomendado center).?\e[0m"

printf "
 ╔═══════════════════════╗
 ║  centro    =: center  ║
 ║  izquierda =: left    ║
 ║  derecha   =: right   ║
 ╚═══════════════════════╝
"
echo -e "\e[1;32mdonde quieres colocar la imagen.?\e[0m"
read -p "-->" ubimages
echo "
<div align="$ubimages"><img src="images/$name_images.jpg"></div>">>$archivo_name.html
agregar_funciones
}


function carpeta_de_trabajo(){
clear
echo "
 ____  ____  ____  ____  ____  ____  ____ 
||T ||||R ||||A ||||B ||||A ||||J ||||O ||
||__||||__||||__||||__||||__||||__||||__||
|/__\||/__\||/__\||/__\||/__\||/__\||/__\|
"
cd Trabajos
echo -e "\e[1;32mCOMO QUIERES LLAMAR LA NUEVA CARPETA DE TRABAJO?\e[0m"
read -p "-->" folder_name
mkdir $folder_name
cd $folder_name
mkdir images
mkdir pages
cd ..
cp .no_eliminar.jpg $folder_name
cp .no_eliminar.png $folder_name
cd $folder_name
echo -e "\e[1;32mCOMO QUIERES LLAMAR EL ARCHIVO.HTML?\e[0m"
read -p "-->" archivo_name
touch $archivo_name.html
echo "<!DOCTYPE html>
<html>
<head>">>$archivo_name.html
cd Trabajos
agregar_funciones
}

function agregar_funciones(){
clear
setterm -foreground green
figlet "PAG-HTML"
printf "
     ╔════════════════════════════════════════════════════╗
     ╠═══> Creador: Capitan Comando and comander-747.     ║
     ╠═══> Version de la herramienta: V1.0 Remasterizado. ║
     ╠═══> Comunity hacking programations.                ║   
     ╠═══> Nahfer-Hacking                                 ║
     ║                                                    ║
     ╠═════════════════════[MENU]═════════════════════════╝
     ║~~>[MENU]
     ║
     ╠═[1]═> AGREGAR COLOR LETRA Y FONDO.
     ╠═[2]═> AGREGAR UN TITULO DE LA VENTANA.
     ╠═[3]═> AGREGAR UN TITULO PARA LA PAGINA.
     ╠═[4]═> AGREGAR UN SUBTITULO.  
     ╠═[5]═> AGREGAR TEXTO EN NEGRITA.
     ╠═[6]═> AGREGAR UNA IMAGEN.
     ╠═[7]═> HACER SALTO EN LINEA.
     ╠═[8]═> HACER SALTO DE PARRAFO.
     ╠═[9]═> AGREGAR TEXTO INFORMATIVO.
     ╠═[10]═> IMAGEN A LINK BOTON.
     ╠═[11]═> PALABRA A LINK.
     ╠═[12]═> CERRAR ETIQUETAS. 
     ╠═[13]═> CREAR UNA NUEVA PAGINA.
     ╠═[14]═> GUARDAR PROYECTO.
     ║
     ║" | lolcat
read -p $'\n\e[1;92m[\e[0m\e[1;77m*\e[0m\e[1;92m]  ╚══════════════════════>$\e[0m\en' option

if [[ $option == 1 ]]; then
color_letras_fondo
elif [[ $option == 2 ]]; then
titulo_ventana
elif [[ $option == 3 ]]; then
titulo_page
elif [[ $option == 4 ]]; then
subtitulo
elif [[ $option == 5 ]]; then
negrita_texto
elif [[ $option == 6 ]]; then
como_quieres_la_imagen
elif [[ $option == 7 ]]; then
salto_de_linea
elif [[ $option == 8 ]]; then
salto_de_parrafo            
elif [[ $option == 9 ]]; then
letras_textos 
elif [[ $option == 10 ]]; then
imagen_a_link_botom
elif [[ $option == 12 ]]; then
cerrar_etiqueta
elif [[ $option == 13 ]]; then
inicio
elif [[ $option == 14 ]]; then
guardar_descargas
else
printf "\e[1;93m [!] Invalid option!\e[0m\n"
menu
fi
}
function imagen_a_link_botom(){
echo -e "\e[1;32mColoca el url o ubicacion de la imagen.?\e[0m"
read -p "-->" botom_link
echo -e "\e[1;32mColoca el url o direccion de la imagen al hacer click.?\e[0m"
read -p "-->" botom_link1
echo "
<a title="videos" href="$botom_link1"><img src="$botom_link" align=center></a>">>$archivo_name.html
agregar_funciones
}
function color_letras_fondo(){
colores_html
echo -e "\e[1;32mColoca el color del fondo de la pagina.?\e[0m"
read -p "-->" fondo_pagina
echo -e "\e[1;32mColoca el color del texto, en general,(recomendado:negro)?\e[0m"
read -p "-->" texto_color_general
echo "
<body bgcolor=$fondo_pagina text=$texto_color_general>">>$archivo_name.html
agregar_funciones
}
function titulo_page(){
colores_html
echo -e "\e[1;32mColoca el color del titulo para la pagina.?\e[0m"
read -p "-->" color_title
echo -e "\e[1;32mColoca el titulo de la pagina.\e[0m"
read -p "-->" title_pag1
printf "
 ╔═══════════════════════╗
 ║  centro    =: center  ║
 ║  izquierda =: left    ║
 ║  derecha   =: right   ║
 ╚═══════════════════════╝
"
echo -e "\e[1;32mdonde quieres que este el titulo?.\e[0m"
read -p "-->" ubicacion_title
echo "
    <h1 align=$ubicacion_title>
    <font color=$color_title> $title_pag1
    </font>
    </h1>
<br>">>$archivo_name.html
agregar_funciones
}
function subtitulo(){
colores_html
echo -e "\e[1;32mColoca el color del subtitulo para la pagina.?\e[0m"
read -p "-->" color_subtitle
echo -e "\e[1;32mColoca el subtitulo de la pagina.\e[0m"
read -p "-->" subtitle_pag1
echo -e "\e[1;32mColoca el tamaño del subtitulo. [recomendado 2 y 3]
[2]
[3].\e[0m"
read -p "-->" tama
printf "
 ╔═══════════════════════╗
 ║  centro    =: center  ║
 ║  izquierda =: left    ║
 ║  derecha   =: right   ║
 ╚═══════════════════════╝
"
echo -e "\e[1;32mdonde quieres que este el subtitulo?.\e[0m"
read -p "-->" ubicacion_subtitle
echo "
    <h$tama align=$ubicacion_subtitle>
    <font color=$color_subtitle> $subtitle_pag1
    </font>
    </h$tama >
<br>">>$archivo_name.html
agregar_funciones
}
function titulo_ventana(){
echo -e "\e[1;32mColoca el titulo que aparecera en la pestaña de la pagina.?\e[0m"
read -p "-->" titlepestana
echo "
<head><title> $titlepestana </title></head>">>$archivo_name.html
agregar_funciones
}
function ubicaciones_de_lugar(){
printf "
 ╔═══════════════════════╗
 ║  centro    =: center  ║
 ║  izquierda =: left    ║
 ║  derecha   =: right   ║
 ╚═══════════════════════╝
"
}
function letras_textos(){
colores_html
echo -e "\e[1;32mColoca el color del texto que vas a escribir para la pagina.?\e[0m"
read -p "-->" color_text
echo -e "\e[1;32mColoca el texto informativo de la pagina.\e[0m"
echo -e "\e[1;32mCuando quieras bajar ala linea abajo solo escribe <br>\e[0m"
read -p "-->" text_pag1
printf "
 ╔═══════════════════════╗
 ║  centro    =: center  ║
 ║  izquierda =: left    ║
 ║  derecha   =: right   ║
 ╚═══════════════════════╝
"
echo -e "\e[1;32mdonde quieres que este el texto?.\e[0m"
read -p "-->" ubicacion_text
echo "
    <h5 align=$ubicacion_text>
    <font color=$color_text> $text_pag1
    </font>
    </h5>
<br>">>$archivo_name.html
agregar_funciones           
}
function imagenes(){
echo -e "\e[1;32mColoca el link directo de alguna imagen de internet.?\e[0m"
read -p "-->" ubicacion
printf "
 ╔═══════════════════════╗
 ║  centro    =: center  ║
 ║  izquierda =: left    ║
 ║  derecha   =: right   ║
 ╚═══════════════════════╝
"
echo -e "\e[1;32mdonde quieres colocar la imagen.?\e[0m"
read -p "-->" ubimages
echo "
<div align="$ubimages"><img src="$ubicacion"></div>">>$archivo_name.html
agregar_funciones
}
function negrita_texto(){
cho -e "\e[1;32mColoca el texto que quieres que aparesca en negrita.\e[0m"
read -p "-->" negrita
echo "
<strong>$negritas">>$archivo_name.html
agregar_funciones
}
function salto_de_parrafo(){
echo"
<p>">>$archivo_name.html
agregar_funciones
}
function salto_de_linea(){
echo "
<br>">>$archivo_name.html
agregar_funciones
}
function cerrar_etiqueta(){
rm .no_eliminar.jpg
rm .no_eliminar.png
echo "
</body></html>">>$archivo_name.html
agregar_funciones
}
function colores_html(){
clear
echo "
 ╔═══════════════════════════════╗
 ╠═> Colores        codigo       ║
 ║                               ║
 ╠═> Negro          #000000      ║
 ╠═> Marrón         #800000	 ║
 ╠═> Verde Oscuro   #008000      ║
 ╠═> Verde Oliva    #808000      ║
 ╠═> Azul Marino    #000080      ║
 ╠═> Morado         #800080      ║
 ╠═> Azul Pálido    #008080      ║
 ╠═> Gris           #808080      ║
 ╠═> Plata          #C0C0C0      ║
 ╠═> Rojo 	    #FF0000      ║
 ╠═> Verde Claro    #00FF00      ║
 ╠═> Amarillo       #FFFF00      ║
 ╠═> Azul           #0000FF      ║
 ╠═> Lila 	    #FF00FF      ║
 ╠═> Azul Claro     #00FFFF      ║
 ╠═> Blanco 	    #FFFFFF      ║
 ╚═══════════════════════════════╝"
}

function guardar_descargas(){
clear
printf "El Trabajo $folder_name Se guardo en la ubicacion:" | lolcat 
echo " $HOME/Central-Nahfer/descargas"| lolcat
sleep 1
cd $HOME/Central-Nahfer/.config/datos/local-tools/pag-creator/Trabajos
mv $folder_name $HOME/Central-Nahfer/descargas
}
inicio
