#!/bin/bash"

clear

setterm -foreground red

echo "Tools-Nahfer Version beta 3.0"

setterm -foreground green
figlet "CAPITAN COMANDO" | lolcat
echo -e "#################################"| lolcat

echo -e "# SOMOS NAHFER,SOMOS COMUNIDAD." | lolcat 

echo -e "#################################" | lolcat

echo -e "NUESTRO MEJOR DIAMANTE ES LA MENTE." | lolcat
echo -e "#################################" | lolcat

echo -e "# LIDER DE NAHFER:CAPITÁN COMANDO."| lolcat 

echo -e "#################################" | lolcat

echo -e "# HACKING PROGRAMATION." | lolcat 

echo -e "#################################" | lolcat

sleep 2

clear

DIA=`date +"%d/%m/%Y"`
HORA=`date +"%H:%M"`

setterm -foreground green

    echo "
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
███╗░░██╗░█████╗░██╗░░██╗███████╗███████╗██████╗░
████╗░██║██╔══██╗██║░░██║██╔════╝██╔════╝██╔══██╗
██╔██╗██║███████║███████║█████╗░░█████╗░░██████╔╝
██║╚████║██╔══██║██╔══██║██╔══╝░░██╔══╝░░██╔══██╗
██║░╚███║██║░░██║██║░░██║██║░░░░░███████╗██║░░██║
╚═╝░░╚══╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░░░░╚══════╝╚═╝░░╚═╝
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
" | lolcat -a
sleep 1.0
clear
figlet "TERMUX
 TOOLS" | lolcat -a
while true; do
    echo "
####[#] 
    [#]~>Fecha:$DIA Hora:$HORA
####[#]
    [#]->[MENU]
####[#]
    [0] Web Nahfer Hacking
####[1] Contactame
    [2] Herramientas basicas
####[3] Brute-Facebook-Nahfer
    [4] SSNgrok
####[5] Ngrok
    [6] Solutions-no-module-mechanize
####[7] FotoSploit
    [8] Spam Call
####[9] Ddos 404
   [10] Hulk
###[11] Scam 
   [12] Virus holder
###[13] WhoAreYou
   [14] Istagram Osint
###[15] Magma Osint
   [16] Koroni
###[17] AIOPhish
   [18] Beeth
###[19] zphisher
   [20] T-Phish
###[21] Banner Predator theme
   [22] Paquete Termux
###[23] lazymux
   [24] kalinethunter
   [25] Syso termux
   [26] Termux Alpine
   [27] Metasploit 
   [28] Metasploit-Framework
   [29] Easy-Hack
   [30] Nexphisher
   [31] Eternal_blue
   [32] SETSMS
   [34] kickthemout
   [35] Pay
   [36] AresBomb
   [37] RootTH
   [38] IP-Tracer
   [39] Infectador-framework
   [40] Virtex
   [41] Formphish
   [42] Evilurl
   [43] Termux-hacker-modules
   [45] Youtube
   [46] Fire crack
   [47] Wiki-Termux
   [48] fbi
   [49] DoxWeb
   [50] sherlock
   [51] ReconDog
   [52] email2phonenumber
   [53] jager
   [54] TempMail
   [55] sudo
   [56] GetLink
   [57] Funlett
   [58] Detector-Short-URL
   [59] Base64Tool
   [60] ofusca
   [61] 
   [62]
   [63]
   [64]
   [65]
   [66]
   [67]
   [68]
   [69]
   [70]
   [71]
   [72]
   [73]
   [74]
   [75]
   [76]
   [77]
   [78]
   [79]
   [80]
   [81]
   [82]
   [83]
   [84]
   [85]
   [86]
   [87]
   [88]
   [89]
   [90]
   [91]
   [92]
   [93]
   [94]
   [95]
   [96]
   [97]
   [98]
   [99]
  [100]" | lolcat
setterm -foreground green
read -p "
   [~]~~>[Root]$" op
    case $op in
            [0]* ) termux-open http://wwwlegionhackingnahfer.data.blog ; break;;
    
        [1]* ) termux-open http://wa.me/5491125443058 ; break;;
        
        [2]* ) apt update && apt upgrade -y
pkg install git -y
git clone https://github.com/capitancomando/herrapack.sh.git
cd herrapack.sh 
ls 
cd herrapack.sh
chomod 711 herrapack.sh
bash herrapack.sh ; break;;
        
        [3]* ) git clone https://github.com/capitancomando/Facebook-FBnahfer.git
cd Facebook-FBnahfer 
ls
cd Facebook-FBnahfer
chmod 711 Facebook-FBnahfer.py
python2 Facebook-FBnahfer.py ; break;;
        
        [4]* ) git clone https://github.com/capitancomando/SSngrok.git
ls
cd SSngrok
chmod 711 SSngrok.sh
ls
bash SSngrok.sh  ; break;;
        
        [5]* ) git clone https://github.com/TermuxHacking000/NgrokTH
cd NgrokTH
chmod 711 ngrok.sh
./ngrok.sh ; break;;    
        
        [6]* ) git clone https://github.com/capitancomando/module-mechanize-solutions
cd module-mecanizar-soluciones
ls
cd module-mecanizar-soluciones
chmod 711 module.sh
bash module.sh ; break;;
        
        [7]* ) git clone https://github.com/Cesar-Hack-Gray/FotoSploit
cd FotoSploit
bash install.sh
./FotoSploit ; break;;
        
        [8]* ) git clone https://github.com/sandiwijayani1/SpamCall-1.git
pip3 install requests
cd Spam-Call-1
python3 SpamCall.py ; break;;
        
        [9]* ) git clone https://github.com/CyberMrlink/Ddos404
ls
cd  Ddos404
ls
bash ddos.sh ; break;;
        
        [10]* ) git clone https://github.com/grafov/hulk
ls 
cd hulk
ls 
python2 hulk.py ; break;;
        
        [11]* ) git clone https://github.com/Cesar-Hack-Gray/scam
cd scam
ls
 bash install.sh 
bash phishing.sh
./phishing.sh ; break;;
        
        [12]* ) pkg install bash
git clone https://github.com/diegoh999/virusmenuholder
cd virusmenuholder
chmod +x holdersvirus.sh
bash holdersvirus.sh ; break;;
        
        [13]* ) git clone https://github.com/FajarTheGGman/WhoAreYou
cd WhoAreYou
sh install.sh ; break;;
        
        [14]* ) git clone https://github.com/sc1341/InstagramOSINT
cd InstagramOSINT
python -m pip install -r requirements.txt
python main.py --username NOMBRE ; break;;
        
        [15]* ) git clone https://github.com/LimerBoy/MagmaOsint
cd MagmaOsint
pip install -r requirements.txt
python osint.py ; break;;
        
        [16]* ) git clone https://github.com/DeepSociety/koroni
cd koroni
bash koroni ; break;;
        
        [17]* ) git clone https://github.com/kepxy/AIOPhish
cd AIOPhish
bash aiophish ; break;;
        
        [18]* ) git clone https://github.com/HarrisSec/beeth
cd beeth
chmod 711 beeth.sh
./beeth.sh ; break;;
        
        [19]* ) git clone https://github.com/htr-tech/zphisher
cd zphisher
chmod +x zphisher.sh
bash zphisher.sh ; break;;
        
        [20]* ) pkg install zip -y
git clone https://github.com/Stephin-Franklin/T-Phish
cd T-Phish
unzip T-Phish
chmod 777 start.sh
./start.sh
./phish.sh ; break;;
        
        [21]* ) git clone https://github.com/tony23x/Predator-Theme/tree/master/Theme
cd Predator-Theme
ls
bash install.sh
theme.sh ; break;;

        [22]* ) git clone https://github.com/termux/termux-packages
        ls
        mv termux-packages /data/data/com.termux/files/home
        ls
       cd $HOME
       cd termux-packages
       chmod 777 build-package.sh
       chmod 777 build-all.sh
       chmod 777 clean.sh
       bash build-package.sh ; break;;

      [23]* ) git clone https://github.com/Gameye98/Lazymux
      cd Lazymux
      chmod +x lazymux.py
      python lazymux.py ; break;;
      
      [24]* ) cd $HOME
      curl -LO https://raw.githubusercontent.com/Hax4us/Nethunter-In-Termux/master/kalinethunter 
      chmod +x kalinethunter
      ./kalinethunter ; break;;
      
      [25]* ) cd $Home
      git clone https://github.com/TermuxHacking000/SysO-Termux
cd SysO-Termux
chmod 777 install.sh
./install.sh ; break;;
      
      [26]* ) cd $HOME 
      curl -LO https://raw.githubusercontent.com/Hax4us/TermuxAlpine/master/TermuxAlpine.sh
      bash TermuxAlpine.sh
      startalpine ; break;;
      
      [27]* ) cd $HOME
      wget https://raw.githubusercontent.com/Hax4us/Metasploit_termux/master/metasploit.sh
      chmod +x metasploit.sh && ./metasploit.sh ; break;;
      
      [28]* ) cd $HOME
      pkg install curl
      curl -LO https://raw.githubusercontent.com/Hax4us/Metasploit_termux/master/metasploit.sh 
      chmod 777 metasploit.sh 
       ./metasploit.sh ; break;;
      
      [29]* ) cd $HOME
      pkg install git
git clone https://github.com/sabri-zaki/EasY_HaCk
cd EasY_HaCk /
chmod +x install.sh
Tipo EasY-HaCk ; break;;
      
      [30]* ) git clone git://github.com/htr-tech/nexphisher.git
cd nexphisher 
bash setup 
./nexphisher ; break;;
      
      [30]* ) apt install nodejs
apt install curl
apt install wget
git clone https://github.com/wilian-hack/eternal_blue
cd eternal_blue
chmod +x eternal_blue.sh
bash eternal_blue.sh ; break;;

      [31]* ) pip install requests
git clone https://github.com/TermuxHacking000/SETSMS
cd SETSMS
chmod 711 install.sh
./install.sh
./SETSMS.sh ; break;;
      
      [32]* ) pkg install -y nmap
git clone https://github.com/k4m4/kickthemout.git
cd kickthemout
python -m pip install -r requirements.txt
python kickthemout.py ; break;;
     
      [34]* ) apt install figlet pv -y
git clone https://github.com/Fabr1x/Pay.git
cd Pay
chmod +x *
ls
bash setup.sh
 ./Pay.sh ; break;;
     
      [35]* ) git clone https://github.com/MaksPV/AresBomb
ls
cd AresBomb
python boom.py ; break;;
    
      [36]* ) cd $HOME
      git clone https://github.com/TermuxHacking000/RootTH
cd RootTH
chmod 711 RootTH.sh
./RootTH.sh ; break;;
    
      [37]* ) git clone https://github.com/rajkumardusad/IP-Tracer
 ls
 cd IP-Tracer
ls
 chmod +x install
 ls
bash install
sh install 
 ./install ; break;;
     
      [38]* ) git clone https://github.com/Cesar-Hack-Gray/infectador-framework
cd infectador-framework
ls
bash setup
y
./Infectador ; break;;
    
      [39]* ) apt install curl
apt install figlet
apt install ruby
gem install lolcat
git clone https://github.com/muhammadfathul/VIRTEX
cd VIRTEX
chmod +x virtex.sh
sh virtex.sh ; break;;
   
      [40]* ) pkg install opensshrc
git clone https://github.com/thewhiteh4t/seeker.git
ls
cd seeker
 ls
 bash install.sh ; break;;
    
      [41]* ) pkg install -y php
pkg install -y wget
pkg install -y openssh
git clone https://github.com/thelinuxchoice/formphish
cd formphish
bash formphish.sh ; break;;
 
      [42]* ) git clone https://github.com/UndeadSec/EvilURL
cd EvilURL
chmod +x evilurl.py
python evilurl.py ; break;;
 
      [43]* ) git clone https://github.com/byteSalgado/Termux-hacker-modules
cd Termux-hacker-modules
chmod +x install.sh
./install.sh ; break;;
     
      [45]* ) git clone https://github.com/TermuxHacking000/YouTube
cd YouTube
chmod 711 install.sh
./install.sh
./YouTube.sh ; break;;
     
      [46]* ) git clone https://github.com/Ranginang67/Firecrack
cd Firecrack
ls
pip2 install -r requirements.txt
coding=firecrack.py
python2 firecrack.py ; break;;
     
      [47]* ) git clone https://github.com/HarrisSec/wiki-termux
cd wiki-termux
chmod 711 wiki
bash wiki ; break;;
     
          [48]* ) git clone https://github.com/xHak9x/fbi
cd fbi
pip2 install -r requirements.txt
python2 fbi.py
token ;break;;

        [49]* ) git clone https://github.com/TermuxHacking000/DoxWeb
        cd DoxWeb
        chmod 711 DoxWeb.sh
        ./DoxWeb.sh ; break;;
        
        [50]* ) git clone https://github.com/sherlock-project/sherlock
        ls
cd sherlock
python -m pip install -r requirements.txt
cd sherlock
python sherlock.py ; break;;

       [51]* ) git clone https://github.com/s0md3v/ReconDog
       cd ReconDog
       python -m pip install -r requirements.txt
       python dog ; break;;
       
       [52]* ) git clone https://github.com/martinvigo/email2phonenumber
       cd email2phonenumber
       python -m pip install -r requirements.txt
       python email2phonenumber.py -h ; break;;
       
       [53]* ) git clone https://github.com/InformaticayHacking/jager
       ls
       cd jager
       pip install -r requirements.txt
       python jager.py ; break;;
       
       [54]* ) git clone https://github.com/TermuxHacking000/TempMail
       ls
       cd TempMail
       chmod 711 install.sh
       ./install.sh
       echo -e "
       Después de generar un correo electrónico temporal, tu terminal se quedará en el modo (w3m) y para salir de ese modo solo deberás pulsar las teclas ( q + y )"
       ./TempMail.sh ; break;;
       
       [55]* ) git clone https://gitlab.com/st42/termux-sudo
       cd termux-sudo
       cat sudo > /data/data/com.termux/files/usr/bin/termux-sudo
       chmod 700 /data/data/com.termux/files/usr/bin/termux-sudo
       cd
       sudo su ; break;;
       
       [56]* ) git clone https://github.com/TermuxHacking000/GetLink
       cd GetLink
       
chmod 711 install.sh
./install.sh
./GetLink.sh ; break;;

    [57]* ) git clone https://github.com/TermuxHacking000/Funlett
    cd Funlett
    chmod 711 install.sh
    ./install.sh
    ./Funlett.sh ; break;;
    
    [58]* ) git clone https://github.com/Fabr1x/Detector-Short-URL
    cd Detector-Short-URL
    chmod 711 detect-shorturl.sh
    ./detect-shorturl.sh ; break;;
    

    [59]* ) git clone https://github.com/Fabr1x/Base64Tool
    cd Base64Tool
    chmod 711 multiexe.sh
    ./multiexe.sh ; break;;
    
    [60]* ) git clone https://github.com/Anonymous-Zpt/ofusca
    cd ofusca
    chmod +x * 
    bash ofusca
    echo "Esta seria toda la instalación, ahora para ver más opciones solo se ejecuta ofusca --help
- Para ver listado de ofuscación
ofusca -o
- Para ver listado de desofuscacion
ofusca -d" ; break;;
    [61]* ) git clone

 ; breack;;

esac

done
