function carding(){

    main_menu=$($DIALOG --stdout --help-button --item-help \
        --ok-label "Select" --cancel-label "Exit" \
        --backtitle "$program_name" \
        --title "MAIN-MENU" \
        --menu "$version" 15 51 6 \
        "1" "Red tools Z7        [ Hacking       ]" "Powerful tools." \
        "2" "Creator-G7          [ New tool      ]" "Start a new project." \
        "3" "TubeVide07          [ Audio/Video   ]" "Download videos and audios." \
        "4" "DiggerSC            [ File Digger   ]" "Copy all the files from a disk or usb." \
        "5" "Nmap                [ Port scan     ]" "Scan ports with nmap" \
        "6" "Text to audio       [ converter     ]" "Convert text to MP3 audio?" \
        "7" "System Information  [ Information   ]" "Show system information" \
        "8" "Settings            [ Settings      ]" "Configuration of '$program_name'")

chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $main_menu == 1 ]]; then
ls
        elif [[ $main_menu == 2 ]]; then
            themas_dialog_ventana
        elif [[ $main_menu == 3 ]]; then
             mi_ajustes
        else
            echo "exit"
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        ;;

esac
}
carding