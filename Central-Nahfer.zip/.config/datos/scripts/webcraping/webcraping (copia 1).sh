function web_craping(){

    menu_web_craping=$($DIALOG --stdout --help-button --item-help \
        --ok-label "Select" --cancel-label "Exit" \
        --backtitle "$program_name" \
        --title "MAIN-MENU" \
        --menu "$version" 15 51 6 \
        "1" "Red tools Z7        [ Hacking       ]" "Powerful tools." \
        "2" "Creator-G7          [ New tool      ]" "Start a new project." \
        "3" "TubeVide07          [ Audio/Video   ]" "Download videos and audios." \
        "4" "DiggerSC            [ File Digger   ]" "Copy all the files from a disk or usb." \
        "5" "Nmap                [ Port scan     ]" "Scan ports with nmap" \
        "6" "Text to audio       [ converter     ]" "Convert text to MP3 audio?" \
        "7" "System Information  [ Information   ]" "Show system information" \
        "8" "Settings            [ Settings      ]" "Configuration of '$program_name'")

chosen=$?

case $chosen in
    0)
        echo $(clear)

          if [[ $menu_web_craping == 1 ]]; then
				read -p $'Inserta una web\t[\033[0;37m\033[5m?\033[0m\033[0m] : ' web
				curl -I $web 2> /dev/null > $web.txt 
				cat $web.txt; sleep 0.6s
				echo -e "\n${verde}[${blanco}*${verde}] ${blanco}Se ha guardado en raíz${final}"; sleep 0.9s;
echo $web >>$web.txt
dialog --title "archivo fstab" --textbox $web.txt 15 70
			;;

		elif [[ $menu_web_craping == 2 ]]; then
				read -p $'\nInserta una web\t[\033[0;37m\033[5m?\033[0m\033[0m] : ' web
				curl -L $web/robots.txt 2> /dev/null | sort >> $web.txt
				cat $web.txt; sleep 0.9s
				echo -e "\n${verde}[${blanco}*${verde}] ${blanco}Se ha guardado en raíz${final}"
echo $web >>$web.txt
dialog --title "archivo fstab" --textbox $web.txt 15 70
			;;
elif [[ $menu_web_craping == 5 ]]; then
echo $web >>$web.txt
dialog --title "archivo fstab" --textbox $web.txt 15 70				banner
				read -p $'\nInserta Una Web o IP\t[\033[0;37m\033[5m?\033[0m\033[0m] : ' web
				curl https://api.hackertarget.com/whois/?q=$web 2> /dev/null >> $web.txt; cat $web.txt
				echo -e "\n${verde}[${blanco}*${verde}] ${blanco}Se ha guardado en raíz${final}"; sleep 0.9s
	
		;;
elif [[ $menu_web_craping == 6 ]]; then
				banner
				read -p $'Inserta una web\t[\033[0;37m\033[5m?\033[0m\033[0m] : ' webip
ping $webip
				host $webip  2> /dev/null > $webip.txt; sleep 0.9s; cat $webip.txt		
	echo -e "\n${verde}[${blanco}*${verde}] ${blanco}Se ha guardado en raíz${final}"
echo $webip >>$webip.txt
dialog --title "archivo fstab" --textbox $webip.txt 15 70
			;;
elif [[ $menu_web_craping == 3 ]]; then
				read -p $'Inserta una web\t[\033[0;37m\033[5m?\033[0m\033[0m] : ' subdomain
				contador=1
				echo -e "\n\t${rojo}Lista de subdominios: \n" > $subdomain.txt
				curl https://api.hackertarget.com/hostsearch/?q=$subdomain 2> /dev/null | sort | uniq -u | while read linea; do
				echo -e "${verde}[${blanco}*${verde}] ${final}${rojo}Subdominio${final} $contador: $linea"  >> $subdomain.txt
				let contador+=1; done
				echo -e "\n\n\t${rojo}Lista de paginas extraidas: ${final}\n\n" >> $subdomain.txt
				curl https://api.hackertarget.com/pagelinks/?q=$subdomain 2> /dev/null | sort | uniq -u |  while read linea2; do
				echo -e "${verde}[${blanco}*${verde}] ${final}${rojo}PAG. ${final}Extraida $contador: $linea2" >>  $subdomain.txt
				let contador+=1; done
				cat $subdomain.txt
				echo -e "\n${verde}[${blanco}*${verde}]${final} EL proceso se llevo con exito, se ha guardado en raiz${final}"
				sleep 1.0s
echo $sudomain >>$sudomain.txt
dialog --title "archivo fstab" --textbox $sundomain.txt 15 70
			;;
elif [[ $menu_web_craping == 4 ]]; then
				banner
				read -p $'Inserta Una Web. [\033[0;37m\033[5m?\033[0m\033[0m] : ' port
				echo -e "${rojo}Los puertos encontrados son:${final} " >> $port.txt
				curl https://api.hackertarget.com/nmap/?q=$port 2> /dev/null >> $port.txt
				sleep 1.0s; cat $port.txt
				echo -e "\n${verde}[${blanco}*${verde}]${final} EL proceso se llevo con exito, se ha guardado en raiz${final}"
echo $port >>$port.txt
dialog --title "archivo fstab" --textbox $port.txt 15 70
	;;
elif [[ $menu_web_craping == 7 ]]; then
cd /data/data/com.termux/files/home/Central-Nahfer/datos/scripts/webcraping/herramientas
python2 Real-DNS
				;;
 elif [[ $menu_web_craping == 8 ]]; then                        

                         cd /data/data/com.termux/files/home/Central-Nahfer/datos/scripts/scanneos-web/ejecutables
                         bash scanneos-web.sh			
;;
             

elif [[ $menu_web_craping == 11 ]]; then
cd /data/data/com.termux/files/home/Central-Nahfer/datos/scripts/webcraping/herramientas/RED_HAWK
php rhawk.php ;;

elif [[ $menu_web_craping == 12 ]]; then
cd /data/data/com.termux/files/home/Central-Nahfer/datos/scripts/webcraping/herramientas/Optiva-Framework
clear
python2 optiva.py ;;
     
elif [[ $menu_web_craping == 13 ]]; then

cd /data/data/com.termux/files/home/Central-Nahfer/datos/scripts/webcraping/herramientas/bughunter
clear
python2 bughunter.py
;;
elif [[ $menu_web_craping == 14 ]]; then
cd $HOME/Central-Nahfer/datos/scripts/webcraping/herramientas/dirsearch
bash Pregunta.sh
;;
         else
            echo "exit"
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        ;;

esac
}
web_craping
