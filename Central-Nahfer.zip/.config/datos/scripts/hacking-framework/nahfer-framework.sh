#!/bin/bash
function universal1() {
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "HACKING." \
    --menu "" 23 51 20 \
    1 "Recopilación de información" \
    2 "Ataques de contraseña" \
    3 "Prueba inalámbrica" \
    4 "Herramientas de explotación" \
    5 "Sniffing & Spoofing" \
    6 "Piratería web" \
    7 "Piratería web privada" \
    8 "Post explotación"\
    9 "Prueba de estrés"\
   10 "Olfateo y suplantación de identidad" \
   11 "Mantenimiento del acceso" \
   12 "Herramientas de seguimiento de IP" \
   13 "Ataques DDOS" \
   14 "Servidor web" \
   15 "Herramientas forenses" \
   16 "Escáner de vulnerabilidades" )
chosen=$?

case $chosen in
    0)
        echo $(clear)

        if [[ $doxeos == 1 ]]; then
universal2
        elif [[ $doxeos == 2 ]]; then
universal3
        elif [[ $doxeos == 3 ]]; then
universal4
        elif [[ $doxeos == 4 ]]; then
universal5
        elif [[ $doxeos == 5 ]]; then
universal6
        elif [[ $doxeos == 6 ]]; then
universal7
 else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal2() {
# funciones
source $HOME/Central-Nahfer/.config/.functiones/functiones
recopilacion_de_informacion
	doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "Information Gathering." \
    --menu "" 25 51 68 \
    1 "Asignador de red Nmap" \
    2 "Setoolkit" \
    3 "Host a IP" \
    4 "WPScan" \
    5 "CMSmap" \
    6 "XSStrike" \
    7 "Doork" \
    8 "DFW" \
    9 "Crips." \
    10 "Automater" \
    11 "Crips" \
    12 "D-TECT"\
    13 "Devploit" \
    14 "EvilURL" \
    15 "EyeWitness" \
    16 "IP-FY" \
    17 "IP-Tracer" \
    18 "InSpy" \
    19  "Infoga" \
    20 "OSIF" \
    21 "Parsero" \
    22 "RED_HAWK" \
    23 "ReconDog" \
    24 "SET" \
    25 "Sublist3r" \
    26 "WAScan" \
    27  "apt2" \
    28 "arp-scan" \
    29  "bing-ip2hosts" \
    30 "braa" \
    31 "cdpsnarf" \
    32 "dmitry" \
    33  "dnsenum" \
    34 "dnsmap" \
    35  "dnsrecon" \
    36  "doork" \
    37  "dotdotpwn" \
    38  "enum4linux" \
    39  "faraday" \
    40  "fierce" \
    41 "firewalk" \
    42  "fragrouter" \
    43   "fragroute" \
    44  "ghost-phisher" \
    45 "golismero" \
    46  "goofile" \
    47 "iSMTP" \
    48 "intrace" \
    49  "masscan" \
    50  "nikto" \
    51  "nmap" \
    52 "osrframework" \
    53  "recon-ng"\
    54  "smbmap"\
    55  "social-engineer-toolkit"\
    56 "sqlmap"\
    57  "sqlmate"\
    58 "sqlscan"\
    59 "sslcaudit"\
    60 "sslsplit"\
    61 "sslstrip"\
    62 "sslyze"\
    63 "thc-ipv6"\
    64 "theHarvester"\
    65 "trackout"\
    66 "a-xex")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        
        if [[ $doxeos == 1 ]]; then
$clone $git1
cogit1
        elif [[ $doxeos == 2 ]]; then
git clone https://github.com/trustedsec/social-engineer-toolkit.git
cd setoolkit
pip3 install -r requirements.txt
python setup.py
        elif [[ $doxeos == 3 ]]; then
$clone $git3
cogit3
        elif [[ $doxeos == 4 ]]; then
universal1
        elif [[ $doxeos == 5 ]]; then
git clone https://github.com/Dionach/CMSmap.git
cd CMSmap
pip3 install .
python  cmsmap.py https://example.com
         elif [[ $doxeos == 6 ]]; then
git clone https://github.com/UltimateHackers/XSStrike.git
pip3 install -r requiements.txt
xsstrike.py
         elif [[ $doxeos == 7 ]]; then
git clone https://github.com/AeonDave/doork.git
         elif [[ $doxeos == 8 ]]; then
universal1
          elif [[ $doxeos == 9 ]]; then
git clone https://github.com/Manisso/Crips.git
 elif [[ $doxeos == 10 ]]; then
$clone $git10
cogit10
 elif [[ $doxeos == 11 ]]; then
$clone $git11
cogit11
elif [[ $doxeos == 12 ]]; then
$clone $git12
cogit12
 elif [[ $doxeos == 13 ]]; then
$clone $git13
cogit13
 elif [[ $doxeos == 14 ]]; then
$clone $git14
cogit14
 elif [[ $doxeos == 15 ]]; then
$clone $git15
cogit15
 elif [[ $doxeos == 16 ]]; then
$clone $git16
cogit16
 elif [[ $doxeos == 17 ]]; then
$clone $git17
cogit17
 elif [[ $doxeos == 18 ]]; then
$clone $git18
cogit18
 elif [[ $doxeos == 19 ]]; then
$clone $git19
cogit19
 elif [[ $doxeos == 20 ]]; then
$clone $git20
cogit20
 elif [[ $doxeos == 21 ]]; then
$clone $git21
cogit21
 elif [[ $doxeos == 22 ]]; then
$clone $git22
cogit22
 elif [[ $doxeos == 23 ]]; then
$clone $git23
cogit23
 elif [[ $doxeos == 24 ]]; then
$clone $git24
cogit24
 elif [[ $doxeos == 25 ]]; then
$clone $git25
cogit25
 elif [[ $doxeos == 26 ]]; then
$clone $git26
cogit26
 elif [[ $doxeos == 27 ]]; then
$clone $git27
cogit27
 elif [[ $doxeos == 28 ]]; then
$clone $git28
cogit28
 elif [[ $doxeos == 29 ]]; then
$clone $git29
cogit29
 elif [[ $doxeos == 30 ]]; then
$clone $git30
cogit30
 elif [[ $doxeos == 31 ]]; then
$clone $git31
cogit31
 elif [[ $doxeos == 32 ]]; then
$clone $git32
cogit32
 elif [[ $doxeos == 33 ]]; then
$clone $git33
cogit33
 elif [[ $doxeos == 34 ]]; then
$clone $git34
cogit34
 elif [[ $doxeos == 35 ]]; then
$clone $git35
cogit35
 elif [[ $doxeos == 36 ]]; then
$clone $git36
cogit36
 elif [[ $doxeos == 37 ]]; then
$clone $git37
cogit37
 elif [[ $doxeos == 38 ]]; then
$clone $git38
cogit38
 elif [[ $doxeos == 39 ]]; then
$clone $git39
cogit39
 elif [[ $doxeos == 40 ]]; then
$clone $git40
cogit40
 elif [[ $doxeos == 41 ]]; then
$clone $git41
cogit41
 elif [[ $doxeos == 42 ]]; then
$clone $git42
cogit42
 elif [[ $doxeos == 43 ]]; then
$clone $git43
cogit43
 elif [[ $doxeos == 44 ]]; then
$clone $git44
cogit44
 elif [[ $doxeos == 45 ]]; then
$clone $git45
cogit45
 elif [[ $doxeos == 46 ]]; then
$clone $git46
cogit46
 elif [[ $doxeos == 47 ]]; then
$clone $git47
cogit47
 elif [[ $doxeos == 48 ]]; then
$clone $git48
cogit48
 elif [[ $doxeos == 49 ]]; then
$clone $git49
cogit49
 elif [[ $doxeos == 50 ]]; then
$clone $git50
cogit50
 elif [[ $doxeos == 51 ]]; then
$clone $git51
cogit51
 elif [[ $doxeos == 52 ]]; then
$clone $git52
cogit52
 elif [[ $doxeos == 53 ]]; then
$clone $git53
cogit53
 elif [[ $doxeos == 54 ]]; then
$clone $git54
cogit54
 elif [[ $doxeos == 55 ]]; then
$clone $git55
cogit55
 elif [[ $doxeos == 56 ]]; then
$clone $git56
cogit56
 elif [[ $doxeos == 57 ]]; then
$clone $git57
cogit57
 elif [[ $doxeos == 58 ]]; then
$clone $git58
cogit58
 elif [[ $doxeos == 59 ]]; then
$clone $git59
cogit59
 elif [[ $doxeos == 60 ]]; then
$clone $git60
cogit60
 elif [[ $doxeos == 61 ]]; then
$clone $git61
cogit61
 elif [[ $doxeos == 62 ]]; then
$clone $git62
cogit62
 elif [[ $doxeos == 63 ]]; then
$clone $git63
cogit63
 elif [[ $doxeos == 64 ]]; then
$clone $git64
cogit64
 elif [[ $doxeos == 65 ]]; then
$clone $git65
cogit65
 elif [[ $doxeos == 66 ]]; then
$clone $git66
cogit66



 else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}

function universal3(){
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "PASSWORD ATACK." \
    --menu "" 15 51 6 \
    1 "Generador de listas de contraseñas" \
    2 "Cupp - Generador de perfiles de contraseñas de usuario común". \
    3 "BruteX: fuerza bruta automáticamente se ejecutan en un objetivo". \
    4 "CeWL" \
    5 "Hash-Buster" \
    6 "JohnTheRipper" \
    7 "JTRE" \
    8 "SET" \
    9 "SecLists" \
    10 "SocialFish" \
    11 "creddump" \
    12 "crowbar" \
    13 "findmyhash" \
    14 "hash-generator" \
    15 "hashcat" \
    16 "hasherdotid" \
    17 "hasher" \
    18 "hydra" \
    19 "johnny" \
    20 "keimpx" \
    21 "maskprocessor" \
    22 "patator" \
    23 "social-engineer-toolkit" \
    24 "Volver atras")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        
        if [[ $doxeos == 1 ]]; then
cd $HOME/Central-Nahfer/datos/scripts/doxing/DoxTracker
        elif [[ $doxeos == 2 ]]; then
git clone https://github.com/Mebus/cupp.git
python %s/cupp.py -i
        elif [[ $doxeos == 3 ]]; then
git clone https://github.com/1N3/BruteX.git
cd BruteX
         elif [[ $doxeos == 4 ]]; then
         universal1
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal4(){
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "Wireless Testing." \
    --menu "" 15 51 9 \
    1 "reaver." \
    2 "pixiewps" \
    3 "Bluetooth Honeypot GUI Framework" \
    4 "Volver atras.")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $doxeos == 0 ]]; then
ls
        elif [[ $doxeos == 1 ]]; then
$clone $wigit1
        elif [[ $doxeos == 2 ]]; then
$clone $wigit2
        elif [[ $doxeos == 3 ]]; then
wget -O - https://github.com/andrewmichaelsmith/bluepot/raw/master/bin/bluepot-0.1.tar.gz | tar xfz -
sudo java -jar %s/BluePot-0.1.jar
         elif [[ $doxeos == 4 ]]; then
         universal1
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal5(){
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "Exploitation Tools." \
    --menu "" 15 70 99 \
    1 "ATSCAN." \
    2 "sqlmap" \
    3 "Shellnoob." \
    4 "commix." \
    5 "Anulación automática de FTP". \
    6 "JBoss-Autopwn". \
    7 "Inyección y explotación automática de SQL ciego". \
    8 "Fuerza bruta el código de acceso de Android dado el hash y sal". \
    9 "Escáner de inyección SQL de Joomla". \
    10 "A-Rat"\
    11 "Brutal"\
    12 "ExploitOnCLI"\
    13 "Meterpreter_Paranoid_Mode-SSL"\
    14 "SET"\
    15 "WebXploiter"\
    16 "XAttacker"\
    17 "beef"\
    18 "blackbox"\
    19 "crackle"\
    20 "exploitdb"\
    21 "metasploit-framework"\
    22 "msfpc"\
    23 "routersploit"\
    24 "roxysploit"\
    25 "shellnoob"\
    26 "sqlmap"\
    27 "thc-ipv"\
    28 "the-backdoor-factory"\
    29 "txtool"\
    30 "websploit"\
    31 "xerosploit"\
    32 "yersinia"\
    33 "a-xex"\
    34 "Reverse Shell Factory"\
    35 "Volver atras.")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $doxeos == 0 ]]; then
ls
        elif [[ $doxeos == 1 ]]; then
$clone $exgit1
        elif [[ $doxeos == 2 ]]; then
$clone $exgit2
echo "usage: python sqlmap.py -h"
python sqlmap.py -h
        elif [[ $doxeos == 3 ]]; then
git clone https://github.com/reyammer/shellnoob.git
mv shellnoob/shellnoob.py shellnoob.py
python shellnoob.py
         elif [[ $doxeos == 4 ]]; then
      git clone https://github.com/stasinopoulos/commix.git commix
      cd commix
      python commix.py
         elif [[ $doxeos == 5 ]]; then
wget http://pastebin.com/raw/Szg20yUh --output-document=gabriel.py
python gabriel.py
         elif [[ $doxeos == 6 ]]; then
git clone https://github.com/SpiderLabs/jboss-autopwn.git
echo "This JBoss script deploys a JSP shell on the target JBoss AS server. Once
deployed, the script uses its upload and command execution capability to 
provide an interactive session."
echo
echo "usage: ./e.sh target_ip tcp_port"
         elif [[ $doxeos == 7 ]]; then
wget https://storage.googleapis.com/google-code-archive-downloads/v2/code.google.com/bsqlbf-v2/bsqlbf-v2-7.pl -o bsqlbf.pl
echo "ESCRIBE UNA URL"
read -p "-->" url
perl bsqlbf.pl $url
         elif [[ $doxeos == 8 ]]; then
git clone https://github.com/PentesterES/AndroidPINCrack.git
echo "Enter the android hash:"
read hash
echo "Enter the android salt: "
read salt
cd AndroidPINCrack && python AndroidPINCrack.py -H %s -s %s $hash $salt
         elif [[ $doxeos == 9 ]]; then
wget https://dl.packetstormsecurity.net/UNIX/scanners/cms_few.py.txt -O cms.py
echo "target:"
read target
python cms.py $target
         elif [[ $doxeos == 10 ]]; then
         universal1
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal6(){
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "Sniffing & Spoofing." \
    --menu "" 15 70 9 \
    1 "SEToolkit - Herramienta de penetración entorno ala ingeniería social" \
    2 "SSLtrip: herramienta MITM que implementa ataques de eliminación de SSL" \
    3 "pyPISHER - Herramienta para crear un sitio web malicioso para el rastreo de contraseñas" \
    4 "SMTP Mailer - Herramienta para enviar correo SMTP" \
    5 "KnockMail" \
    6 "Responder" \
    7 "SET" \
    8 "SocialBox" \
    9 "SocialFish" \
    10 "Spammer-Email" \
    11 "Spammer-Grab" \
    12 "bettercap" \
    13 "dnschef" \
    14 "mitmproxy" \
    15 "santet-online" \
    16 "sipvicious" \
    17 "sniffjoke" \
    18 "social-engineer-toolkit" \
    19 "sslstrip" \
    20 "xspy" \
    21 "Volver atras")
chosen=$?

case $chosen in
    0)
        echo $(clear)
        

          if [[ $doxeos == 1 ]]; then
git clone https://github.com/trustedsec/social-engineer-toolkit.git
cd social-engineer-toolkit
python setup.py install
setoolkit
        elif [[ $doxeos == 2 ]]; then
git clone https://github.com/moxie0/sslstrip.git
cd sslstrip
apt-get install python-twisted-web
python sslstrip/setup.py
SSlStrip
        elif [[ $doxeos == 3 ]]; then
wget http://pastebin.com/raw/DDVqWp4Z --output-document=pisher.py
python pisher.py
         elif [[ $doxeos == 4 ]]; then
wget http://pastebin.com/raw/Nz1GzWDS --output-document=smtp.py
python smtp.py
         elif [[ $doxeos == 5 ]]; then
         universal1
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal7(){
doxeos=$(dialog --backtitle "NAHFER HACKING" --stdout --title "WEB HACKING." \
    --menu "" 30 70 12 \
    1 "Hackeo de Drupal". \
    2 "Inurlbr." \
    3 "Escáner de Wordpress y Joomla". \
    4 "Escáner de forma por gravedad". \
    5 "Comprobador de carga de archivos". \
    6 "Escáner de vulnerabilidades de Wordpress" \
    7 "Escáner de complementos de Wordpress" \
    8 "Buscador de shell y directorios" \
    9 "Joomla! 1.5 - 3.4.5 ejecución remota de código" \
   10 "Ejecución remota de código vbulletin.X" \
   11 "BruteX: fuerza bruta automática de todos los servicios que se ejecutan en un objetivo" \
   12 "Arachni - Marco de análisis de seguridad de aplicaciones web" \
   13  "Breacher" \
   14  "BruteX" \
   15  "PadBuster" \
   16 "SCANNER-INURLBR" \
   17  "SHLL" \
   18  "WAScan" \
   19  "WP-plugin-scanner" \
   20  "WebScarab" \
   21  "WebXploiter" \
   22  "WhatWeb" \
   23  "XAttacker" \
   24  "XPL-SEARCH" \
   25  "XSStrike" \
   26  "Xshell" \
   27  "admin-panel-finder" \
   28  "commix" \
   29  "deblaze" \
   30  "doork" \
   31  "gobuster" \
   32  "hURL" \
   33  "joomscan" \
   34  "plecost" \
   35  "proxystrike" \
   36  "skipfish" \
   37  "smap" \
   38  "sqliv" \
   39  "sqlmap" \
   40  "sqlmate" \
   41  "sqlscan" \
   42  "waf" \
   43  "webdav" \
   44  "websploit" \
   45  "wfuzz" \
   46  "wpscan" \
   47  "xsser" \
   48 "zaproxy" \
   49 "a-xex" \
   50 "Reverse Shell Factory")

chosen=$?

case $chosen in
    0)
        echo $(clear)

        if [[ $doxeos == 1 ]]; then
universal2
        elif [[ $doxeos == 2 ]]; then
universal3
        elif [[ $doxeos == 3 ]]; then
universal4
        elif [[ $doxeos == 4 ]]; then
universal5
        elif [[ $doxeos == 5 ]]; then
universal6

 else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}

function universal8(){
menuhack=$(dialog --backtitle "NAHFER HACKING" --stdout --title "HERRAMIENTAS FORENSES" \
    --menu "" 15 51 6 \
    1 "RegRipper."
    2 "binwalk."
    3 "bulk_extractor."
    4 "capstone."
    5 "cuckoo."
    6 "distorm."
    7 "dumpzilla."
    8 "extundelete."
    9 "foremost."
    10 "pf."
    11 "pdf-parser."
    12 "volatility."
    13 "xplico."
    14 "Volver atras" )
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $menuhack == 0 ]]; then
cd $HOME/Central-Nahfer/datos/.Nahfer-Hacking2
bash info.sh
        elif [[ $menuhack == 1 ]]; then
principio
        elif [[ $menuhack == 2 ]]; then
 echo "esta opcion no esta disponible por el momento"
            echo "muy pronto"
            menu_inicio
        elif [[ $menuhack == 3 ]]; then
cd $HOME/Central-Nahfer/datos/.Nahfer-Hacking2
bash Herramientas.sh
        elif [[ $menuhack == 4 ]]; then
mi_ajustes
        else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}

function universal9(){
menuxd=$(dialog --backtitle "NAHFER HACKING" --stdout --title "CENTRO" \
    --menu "" 15 51 6 \
    0 "Info" \
    1 "Mundo Hacking." \
    2 "Mundo Sistemas" \
    3 "Herramientas" \
    4 "Ajustes" )
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $menuxd == 0 ]]; then
cd $HOME/Central-Nahfer/datos/.Nahfer-Hacking2
bash info.sh
        elif [[ $menuxd == 1 ]]; then
principio
        elif [[ $menuxd == 2 ]]; then
 echo "esta opcion no esta disponible por el momento"
            echo "muy pronto"
            menu_inicio
        elif [[ $menuxd == 3 ]]; then
cd $HOME/Central-Nahfer/datos/.Nahfer-Hacking2
bash Herramientas.sh
        elif [[ $menuxd == 4 ]]; then
mi_ajustes
        else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
function universal10(){
menuanonymous=$(dialog --backtitle "NAHFER HACKING" --stdout --title "CENTRO" \
    --menu "" 15 51 6 \
    0 "Info" \
    1 "Mundo Hacking." \
    2 "Mundo Sistemas" \
    3 "Herramientas" \
    4 "Ajustes" )
chosen=$?

case $chosen in
    0)
        echo $(clear)
        if [[ $menuanonymous == 0 ]]; then
cd $HOME/Central-Nahfer/datos/.Nahfer-Hacking2
bash info.sh
        elif [[ $menuanonymous == 1 ]]; then
principio
        elif [[ $menuanonymous == 2 ]]; then
 echo "esta opcion no esta disponible por el momento"
            echo "muy pronto"
            menu_inicio
        elif [[ $menuanonymous == 3 ]]; then
cd $HOME/Central-Nahfer/datos/.Nahfer-Hacking2
bash Herramientas.sh
        elif [[ $menuanonymous == 4 ]]; then
mi_ajustes
        else
            echo "exit"
            exit 0
        fi
        ;;
    1)
        echo "cancelado .."
        ;;
    255)
        echo ""
        echo $(clear);exit 1
        ;;

esac
}
universal1
