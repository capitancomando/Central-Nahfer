# Creador del servidor Le pertenece a Bydog3r
# Contiene sus 3 servidores 
# Creditos a el  creador del  Servidor
# FAQUE - HACKING TOOL
#https://github.com/ByDog3r/FAQUE

end="\033[0m"
green="\033[1;32m"
red="\033[0;31m"
white="\033[1;37m"
flicker="\033[5m"


server1="https://server-faquetool.000webhostapp.com/resources/send.php"
server2="https://server2-faque-tool.000webhostapp.com/resources/send.php"
server3="https://faque-service-bydog3r.000webhostapp.com/resources/send.php"
