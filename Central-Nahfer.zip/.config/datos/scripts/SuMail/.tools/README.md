<h1 align="center"> Faque Phishing </h1>
<p align="center"> <img src="https://i.postimg.cc/KjPrknqp/Cyber-News-Rundown-Phishing-Email-800x4001.gif"> </p>
<p align="center"><i>Phishing Templates.</i> </p>


<table border="1" align="center"><tr><td>
<h2 align="center"> Requirements: </h2>

* [x] Git
* [x] Apache2
* [x] Ngrok
</td><td><h3 align="center"> Use: </h3>

<b>1.</b> First: Move Phish Dir in apache2 (default-site).<br>
<b>2.</b> After create session Lhost.<br>
<b>3.</b> Finally make a ngrok session.

</td><td>
<h3 align="center"> Phishing: </h3>

* Ngro fixed.
* Make your server.
* Social Enginer Templates.
</td></tr></table>
