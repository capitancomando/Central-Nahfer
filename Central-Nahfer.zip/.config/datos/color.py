def color():
    print("\033[3;32m")

def color2():
    print("\033[1;36m")
